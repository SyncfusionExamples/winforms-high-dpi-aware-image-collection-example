namespace WF_Word
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>fmin
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Syncfusion.Windows.Forms.Tools.Office2016ColorTable office2016ColorTable1 = new Syncfusion.Windows.Forms.Tools.Office2016ColorTable();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem1 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem2 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem3 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem4 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem5 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem6 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem7 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem8 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem9 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem toolStripGalleryItem10 = new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItem();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage1 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage2 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage3 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage4 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage5 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage6 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage7 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage8 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage9 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage10 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage11 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage12 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage13 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage14 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage15 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage16 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage17 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage18 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage19 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage20 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage21 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage22 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage23 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage24 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage25 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage26 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage27 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage28 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage29 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage30 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage31 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage32 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage33 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage34 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage35 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage36 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage37 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage38 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage39 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage40 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            Syncfusion.Windows.Forms.Tools.DPIAwareImage dpiAwareImage41 = new Syncfusion.Windows.Forms.Tools.DPIAwareImage();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.wordribbon = new Syncfusion.Windows.Forms.Tools.RibbonControlAdv();
            this.backStageView1 = new Syncfusion.Windows.Forms.BackStageView(this.components);
            this.backStage1 = new Syncfusion.Windows.Forms.BackStage();
            this.infobackStageTab = new Syncfusion.Windows.Forms.BackStageTab();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.sizevaluelabel = new System.Windows.Forms.Label();
            this.sizelabel = new System.Windows.Forms.Label();
            this.lastAccessValueLabel = new System.Windows.Forms.Label();
            this.lengthvaluelabel = new System.Windows.Forms.Label();
            this.createdTimeValuelabel = new System.Windows.Forms.Label();
            this.lastAccessTimeLabel = new System.Windows.Forms.Label();
            this.createdTimelabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.documentLabel = new System.Windows.Forms.Label();
            this.openbackStageTab = new Syncfusion.Windows.Forms.BackStageTab();
            this.savebackStageTab = new Syncfusion.Windows.Forms.BackStageButton();
            this.saveAsbackStageTab = new Syncfusion.Windows.Forms.BackStageTab();
            this.printbackStageTab = new Syncfusion.Windows.Forms.BackStageTab();
            this.backStageSeparator1 = new Syncfusion.Windows.Forms.BackStageSeparator();
            this.backStageTab1 = new Syncfusion.Windows.Forms.BackStageTab();
            this.backStageButton1 = new Syncfusion.Windows.Forms.BackStageButton();
            this.closebackStageButton = new Syncfusion.Windows.Forms.BackStageButton();
            this.homeTab = new Syncfusion.Windows.Forms.Tools.ToolStripTabItem();
            this.clipBoardtoolStrip = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.pasteSplitButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripPanelItem1 = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.cutButton = new System.Windows.Forms.ToolStripButton();
            this.copyButton = new System.Windows.Forms.ToolStripButton();
            this.fonttoolStrip = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.fontBasePanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.fontUpperPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.fontComboBox = new Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx();
            this.sizeComboBox = new Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx();
            this.increaseFontSizeButton = new System.Windows.Forms.ToolStripButton();
            this.decreaseFontSizeButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.changeCaseDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.upperCaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowerCaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capitializeEachWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontLowerPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.boldToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.italicToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.underlineButton = new System.Windows.Forms.ToolStripButton();
            this.strikeThroughButton = new System.Windows.Forms.ToolStripButton();
            this.subScriptButton = new System.Windows.Forms.ToolStripButton();
            this.superScriptButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.highlightSplitButton = new System.Windows.Forms.ToolStripSplitButton();
            this.fontColorSplitButton = new System.Windows.Forms.ToolStripSplitButton();
            this.paragraphToolStrip = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.paragraphBasePanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.paragraphupPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.bulletSplitButton = new System.Windows.Forms.ToolStripSplitButton();
            this.noneMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bulletMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decIndentButton = new System.Windows.Forms.ToolStripButton();
            this.incIndentButton = new System.Windows.Forms.ToolStripButton();
            this.paragraphdownPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.leftButton = new System.Windows.Forms.ToolStripButton();
            this.centerButton = new System.Windows.Forms.ToolStripButton();
            this.rightButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripEx2 = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.toolStripGallery1 = new Syncfusion.Windows.Forms.Tools.ToolStripGallery();
            this.insertTab = new Syncfusion.Windows.Forms.Tools.ToolStripTabItem();
            this.pagesToolStripEx = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.coverPageDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.specDesignToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportDeisgnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coverLetterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blankPagetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.illustrationtoolStrip = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.pictureButton = new System.Windows.Forms.ToolStripButton();
            this.layoutTabItem = new Syncfusion.Windows.Forms.Tools.ToolStripTabItem();
            this.pageSetUptoolStrip = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.marginDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.normalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.narrowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moderateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orientationDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.landscapeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.portraitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sizeDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.letterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabloidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.legalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.executiveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.a3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.a4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripEx1 = new Syncfusion.Windows.Forms.Tools.ToolStripEx();
            this.indentPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.indentLabel = new System.Windows.Forms.ToolStripLabel();
            this.leftPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.leftLabel = new System.Windows.Forms.ToolStripLabel();
            this.rightPanelItem = new Syncfusion.Windows.Forms.Tools.ToolStripPanelItem();
            this.rightLabel = new System.Windows.Forms.ToolStripLabel();
            this.recenttreeMenuItem = new Syncfusion.Windows.Forms.Tools.TreeMenuItem();
            this.thisPCtreeMenuItem = new Syncfusion.Windows.Forms.Tools.TreeMenuItem();
            this.SaveAsPCtreeMenuItem = new Syncfusion.Windows.Forms.Tools.TreeMenuItem();
            this.saveAsToppanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.imageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteSpecialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.sentenceCaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rtbpanel = new System.Windows.Forms.Panel();
            this.statusStripEx1 = new Syncfusion.Windows.Forms.Tools.StatusStripEx();
            this.trackBarItem1 = new Syncfusion.Windows.Forms.Tools.TrackBarItem();
            this.statusStripLabel1 = new Syncfusion.Windows.Forms.Tools.StatusStripLabel();
            this.statusStripLabel2 = new Syncfusion.Windows.Forms.Tools.StatusStripLabel();
            this.imageListAdv1 = new Syncfusion.Windows.Forms.Tools.ImageListAdv(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.wordribbon)).BeginInit();
            this.wordribbon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backStage1)).BeginInit();
            this.backStage1.SuspendLayout();
            this.infobackStageTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.homeTab.Panel.SuspendLayout();
            this.clipBoardtoolStrip.SuspendLayout();
            this.fonttoolStrip.SuspendLayout();
            this.paragraphToolStrip.SuspendLayout();
            this.toolStripEx2.SuspendLayout();
            this.insertTab.Panel.SuspendLayout();
            this.pagesToolStripEx.SuspendLayout();
            this.illustrationtoolStrip.SuspendLayout();
            this.layoutTabItem.Panel.SuspendLayout();
            this.pageSetUptoolStrip.SuspendLayout();
            this.toolStripEx1.SuspendLayout();
            this.saveAsToppanel.SuspendLayout();
            this.rtbpanel.SuspendLayout();
            this.statusStripEx1.SuspendLayout();
            this.SuspendLayout();
            // 
            // wordribbon
            // 
            this.wordribbon.AutoLayoutToolStrip = true;
            this.wordribbon.BackStageView = this.backStageView1;
            this.wordribbon.CollapseBehavior = Syncfusion.Windows.Forms.Tools.CollapseBehavior.Office2010;
            this.wordribbon.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.wordribbon.Header.AddMainItem(homeTab);
            this.wordribbon.Header.AddMainItem(insertTab);
            this.wordribbon.Header.AddMainItem(layoutTabItem);
            this.wordribbon.Location = new System.Drawing.Point(1, 0);
            this.wordribbon.Margin = new System.Windows.Forms.Padding(2);
            this.wordribbon.MenuButtonFont = new System.Drawing.Font("Segoe UI", 8.25F);
            this.wordribbon.MenuButtonText = "File";
            this.wordribbon.MenuButtonWidth = 56;
            this.wordribbon.MenuColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.wordribbon.Name = "wordribbon";
            office2016ColorTable1.CheckedTabForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(87)))), ((int)(((byte)(154)))));
            office2016ColorTable1.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(87)))), ((int)(((byte)(154)))));
            office2016ColorTable1.HoverCollapsedDropDownButtonForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            office2016ColorTable1.QATDropDownForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            office2016ColorTable1.SelectedTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(109)))), ((int)(((byte)(181)))));
            office2016ColorTable1.TabBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(87)))), ((int)(((byte)(154)))));
            this.wordribbon.Office2016ColorTable.Add(office2016ColorTable1);
            this.wordribbon.OfficeColorScheme = Syncfusion.Windows.Forms.Tools.ToolStripEx.ColorScheme.Managed;
            // 
            // wordribbon.OfficeMenu
            // 
            this.wordribbon.OfficeMenu.Name = "OfficeMenu";
            this.wordribbon.OfficeMenu.ShowItemToolTips = true;
            this.wordribbon.OfficeMenu.Size = new System.Drawing.Size(12, 65);
            this.wordribbon.QuickPanelImageLayout = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wordribbon.QuickPanelVisible = false;
            this.wordribbon.RibbonHeaderImage = Syncfusion.Windows.Forms.Tools.RibbonHeaderImage.None;
            this.wordribbon.RibbonStyle = Syncfusion.Windows.Forms.Tools.RibbonStyle.Office2016;
            this.wordribbon.SelectedTab = this.homeTab;
            this.wordribbon.ShowRibbonDisplayOptionButton = true;
            this.wordribbon.Size = new System.Drawing.Size(1036, 160);
            this.wordribbon.SystemText.QuickAccessDialogDropDownName = "Start menu";
            this.wordribbon.SystemText.RenameDisplayLabelText = "&Display Name:";
            this.wordribbon.TabIndex = 0;
            this.wordribbon.Text = "ribbonControlAdv1";
            this.wordribbon.ThemeName = "Office2016";
            this.wordribbon.TitleColor = System.Drawing.Color.Black;
            // 
            // backStageView1
            // 
            this.backStageView1.BackStage = this.backStage1;
            this.backStageView1.HostControl = null;
            this.backStageView1.HostForm = this;
            // 
            // backStage1
            // 
            this.backStage1.AllowDrop = true;
            this.backStage1.BackStagePanelWidth = 130;
            this.backStage1.BeforeTouchSize = new System.Drawing.Size(1032, 552);
            this.backStage1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.backStage1.ChildItemSize = new System.Drawing.Size(80, 140);
            this.backStage1.Controls.Add(this.infobackStageTab);
            this.backStage1.Controls.Add(this.openbackStageTab);
            this.backStage1.Controls.Add(this.savebackStageTab);
            this.backStage1.Controls.Add(this.saveAsbackStageTab);
            this.backStage1.Controls.Add(this.printbackStageTab);
            this.backStage1.Controls.Add(this.backStageSeparator1);
            this.backStage1.Controls.Add(this.backStageTab1);
            this.backStage1.Controls.Add(this.backStageButton1);
            this.backStage1.Controls.Add(this.closebackStageButton);
            this.backStage1.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.backStage1.ItemSize = new System.Drawing.Size(130, 40);
            this.backStage1.Location = new System.Drawing.Point(0, 0);
            this.backStage1.Margin = new System.Windows.Forms.Padding(2);
            this.backStage1.Name = "backStage1";
            this.backStage1.OfficeColorScheme = Syncfusion.Windows.Forms.Tools.ToolStripEx.ColorScheme.Managed;
            this.backStage1.Size = new System.Drawing.Size(1032, 552);
            this.backStage1.TabIndex = 2;
            this.backStage1.ThemeName = "BackStage2016Renderer";
            this.backStage1.Visible = false;
            // 
            // infobackStageTab
            // 
            this.infobackStageTab.Accelerator = "";
            this.infobackStageTab.BackColor = System.Drawing.Color.White;
            this.infobackStageTab.Controls.Add(this.panel1);
            this.infobackStageTab.Image = null;
            this.infobackStageTab.ImageSize = new System.Drawing.Size(16, 16);
            this.infobackStageTab.Location = new System.Drawing.Point(129, 0);
            this.infobackStageTab.Margin = new System.Windows.Forms.Padding(2);
            this.infobackStageTab.Name = "infobackStageTab";
            this.infobackStageTab.Position = new System.Drawing.Point(11, 51);
            this.infobackStageTab.ShowCloseButton = true;
            this.infobackStageTab.Size = new System.Drawing.Size(903, 552);
            this.infobackStageTab.TabIndex = 3;
            this.infobackStageTab.Text = "Info";
            this.infobackStageTab.ThemesEnabled = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(903, 552);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.sizevaluelabel);
            this.panel2.Controls.Add(this.sizelabel);
            this.panel2.Controls.Add(this.lastAccessValueLabel);
            this.panel2.Controls.Add(this.lengthvaluelabel);
            this.panel2.Controls.Add(this.createdTimeValuelabel);
            this.panel2.Controls.Add(this.lastAccessTimeLabel);
            this.panel2.Controls.Add(this.createdTimelabel);
            this.panel2.Controls.Add(this.lengthLabel);
            this.panel2.Controls.Add(this.documentLabel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(334, 552);
            this.panel2.TabIndex = 2;
            // 
            // sizevaluelabel
            // 
            this.sizevaluelabel.AutoEllipsis = true;
            this.sizevaluelabel.AutoSize = true;
            this.sizevaluelabel.Location = new System.Drawing.Point(173, 69);
            this.sizevaluelabel.Name = "sizevaluelabel";
            this.sizevaluelabel.Size = new System.Drawing.Size(0, 13);
            this.sizevaluelabel.TabIndex = 8;
            // 
            // sizelabel
            // 
            this.sizelabel.AutoSize = true;
            this.sizelabel.Location = new System.Drawing.Point(16, 69);
            this.sizelabel.Name = "sizelabel";
            this.sizelabel.Size = new System.Drawing.Size(27, 13);
            this.sizelabel.TabIndex = 7;
            this.sizelabel.Text = "Size";
            // 
            // lastAccessValueLabel
            // 
            this.lastAccessValueLabel.AutoEllipsis = true;
            this.lastAccessValueLabel.AutoSize = true;
            this.lastAccessValueLabel.Location = new System.Drawing.Point(173, 202);
            this.lastAccessValueLabel.Name = "lastAccessValueLabel";
            this.lastAccessValueLabel.Size = new System.Drawing.Size(0, 13);
            this.lastAccessValueLabel.TabIndex = 6;
            // 
            // lengthvaluelabel
            // 
            this.lengthvaluelabel.AutoEllipsis = true;
            this.lengthvaluelabel.AutoSize = true;
            this.lengthvaluelabel.Location = new System.Drawing.Point(173, 110);
            this.lengthvaluelabel.Name = "lengthvaluelabel";
            this.lengthvaluelabel.Size = new System.Drawing.Size(0, 13);
            this.lengthvaluelabel.TabIndex = 5;
            // 
            // createdTimeValuelabel
            // 
            this.createdTimeValuelabel.AutoEllipsis = true;
            this.createdTimeValuelabel.AutoSize = true;
            this.createdTimeValuelabel.Location = new System.Drawing.Point(173, 153);
            this.createdTimeValuelabel.Name = "createdTimeValuelabel";
            this.createdTimeValuelabel.Size = new System.Drawing.Size(0, 13);
            this.createdTimeValuelabel.TabIndex = 4;
            // 
            // lastAccessTimeLabel
            // 
            this.lastAccessTimeLabel.AutoSize = true;
            this.lastAccessTimeLabel.Location = new System.Drawing.Point(16, 202);
            this.lastAccessTimeLabel.Name = "lastAccessTimeLabel";
            this.lastAccessTimeLabel.Size = new System.Drawing.Size(89, 13);
            this.lastAccessTimeLabel.TabIndex = 3;
            this.lastAccessTimeLabel.Text = "Last Access Time";
            // 
            // createdTimelabel
            // 
            this.createdTimelabel.AutoSize = true;
            this.createdTimelabel.Location = new System.Drawing.Point(16, 156);
            this.createdTimelabel.Name = "createdTimelabel";
            this.createdTimelabel.Size = new System.Drawing.Size(73, 13);
            this.createdTimelabel.TabIndex = 2;
            this.createdTimelabel.Text = "Created Time";
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(16, 110);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(43, 13);
            this.lengthLabel.TabIndex = 1;
            this.lengthLabel.Text = "Length";
            // 
            // documentLabel
            // 
            this.documentLabel.AutoSize = true;
            this.documentLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.documentLabel.Location = new System.Drawing.Point(14, 12);
            this.documentLabel.Name = "documentLabel";
            this.documentLabel.Size = new System.Drawing.Size(50, 30);
            this.documentLabel.TabIndex = 0;
            this.documentLabel.Text = "Info";
            // 
            // openbackStageTab
            // 
            this.openbackStageTab.Accelerator = "";
            this.openbackStageTab.BackColor = System.Drawing.Color.White;
            this.openbackStageTab.Image = null;
            this.openbackStageTab.ImageSize = new System.Drawing.Size(16, 16);
            this.openbackStageTab.Location = new System.Drawing.Point(129, 0);
            this.openbackStageTab.Margin = new System.Windows.Forms.Padding(2);
            this.openbackStageTab.Name = "openbackStageTab";
            this.openbackStageTab.Position = new System.Drawing.Point(52, 92);
            this.openbackStageTab.ShowCloseButton = true;
            this.openbackStageTab.Size = new System.Drawing.Size(903, 552);
            this.openbackStageTab.TabIndex = 5;
            this.openbackStageTab.Text = "Open";
            this.openbackStageTab.ThemesEnabled = false;
            // 
            // savebackStageTab
            // 
            this.savebackStageTab.Accelerator = "";
            this.savebackStageTab.BackColor = System.Drawing.Color.White;
            this.savebackStageTab.Location = new System.Drawing.Point(10, 92);
            this.savebackStageTab.Margin = new System.Windows.Forms.Padding(2);
            this.savebackStageTab.Name = "savebackStageTab";
            this.savebackStageTab.Size = new System.Drawing.Size(110, 25);
            this.savebackStageTab.TabIndex = 6;
            this.savebackStageTab.Text = "Save";
            // 
            // saveAsbackStageTab
            // 
            this.saveAsbackStageTab.Accelerator = "";
            this.saveAsbackStageTab.BackColor = System.Drawing.Color.White;
            this.saveAsbackStageTab.Image = null;
            this.saveAsbackStageTab.ImageSize = new System.Drawing.Size(16, 16);
            this.saveAsbackStageTab.Location = new System.Drawing.Point(129, 0);
            this.saveAsbackStageTab.Margin = new System.Windows.Forms.Padding(2);
            this.saveAsbackStageTab.Name = "saveAsbackStageTab";
            this.saveAsbackStageTab.Position = new System.Drawing.Point(93, 133);
            this.saveAsbackStageTab.ShowCloseButton = true;
            this.saveAsbackStageTab.Size = new System.Drawing.Size(903, 552);
            this.saveAsbackStageTab.TabIndex = 7;
            this.saveAsbackStageTab.Text = "Save As";
            this.saveAsbackStageTab.ThemesEnabled = false;
            // 
            // printbackStageTab
            // 
            this.printbackStageTab.Accelerator = "";
            this.printbackStageTab.BackColor = System.Drawing.Color.White;
            this.printbackStageTab.Image = null;
            this.printbackStageTab.ImageSize = new System.Drawing.Size(16, 16);
            this.printbackStageTab.Location = new System.Drawing.Point(129, 0);
            this.printbackStageTab.Margin = new System.Windows.Forms.Padding(2);
            this.printbackStageTab.Name = "printbackStageTab";
            this.printbackStageTab.Position = new System.Drawing.Point(134, 174);
            this.printbackStageTab.ShowCloseButton = true;
            this.printbackStageTab.Size = new System.Drawing.Size(903, 552);
            this.printbackStageTab.TabIndex = 8;
            this.printbackStageTab.Text = "Print";
            this.printbackStageTab.ThemesEnabled = false;
            // 
            // backStageSeparator1
            // 
            this.backStageSeparator1.Location = new System.Drawing.Point(0, 0);
            this.backStageSeparator1.Name = "backStageSeparator1";
            this.backStageSeparator1.Size = new System.Drawing.Size(90, 1);
            this.backStageSeparator1.TabIndex = 0;
            // 
            // backStageTab1
            // 
            this.backStageTab1.Accelerator = "";
            this.backStageTab1.BackColor = System.Drawing.Color.White;
            this.backStageTab1.Image = null;
            this.backStageTab1.ImageSize = new System.Drawing.Size(16, 16);
            this.backStageTab1.Location = new System.Drawing.Point(129, 0);
            this.backStageTab1.Name = "backStageTab1";
            this.backStageTab1.Position = new System.Drawing.Point(175, 215);
            this.backStageTab1.ShowCloseButton = true;
            this.backStageTab1.Size = new System.Drawing.Size(903, 552);
            this.backStageTab1.TabIndex = 10;
            this.backStageTab1.Text = "Account";
            this.backStageTab1.ThemesEnabled = false;
            // 
            // backStageButton1
            // 
            this.backStageButton1.Accelerator = "";
            this.backStageButton1.BackColor = System.Drawing.Color.Transparent;
            this.backStageButton1.Location = new System.Drawing.Point(10, 240);
            this.backStageButton1.Name = "backStageButton1";
            this.backStageButton1.Size = new System.Drawing.Size(110, 25);
            this.backStageButton1.TabIndex = 11;
            this.backStageButton1.Text = "Options";
            // 
            // closebackStageButton
            // 
            this.closebackStageButton.Accelerator = "";
            this.closebackStageButton.BackColor = System.Drawing.Color.Transparent;
            this.closebackStageButton.Location = new System.Drawing.Point(10, 265);
            this.closebackStageButton.Name = "closebackStageButton";
            this.closebackStageButton.Size = new System.Drawing.Size(110, 25);
            this.closebackStageButton.TabIndex = 9;
            this.closebackStageButton.Text = "Close";
            this.closebackStageButton.Click += new System.EventHandler(this.closebackStageButton_Click);
            // 
            // homeTab
            // 
            this.homeTab.Name = "homeTab";
            // 
            // wordribbon.ribbonPanel1
            // 
            this.homeTab.Panel.Controls.Add(this.clipBoardtoolStrip);
            this.homeTab.Panel.Controls.Add(this.fonttoolStrip);
            this.homeTab.Panel.Controls.Add(this.paragraphToolStrip);
            this.homeTab.Panel.Controls.Add(this.toolStripEx2);
            this.homeTab.Panel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.homeTab.Panel.Name = "ribbonPanel1";
            this.homeTab.Panel.Padding = new System.Windows.Forms.Padding(0, 1, 26, 0);
            this.homeTab.Panel.ScrollPosition = 0;
            this.homeTab.Panel.TabIndex = 2;
            this.homeTab.Panel.Text = "Home";
            this.homeTab.Position = 0;
            this.homeTab.Size = new System.Drawing.Size(59, 31);
            this.homeTab.Tag = "1";
            this.homeTab.Text = "Home";
            // 
            // clipBoardtoolStrip
            // 
            this.clipBoardtoolStrip.CollapsedDropDownButtonText = "Clipboard";
            this.clipBoardtoolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.clipBoardtoolStrip.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.clipBoardtoolStrip.ForeColor = System.Drawing.Color.MidnightBlue;
            this.clipBoardtoolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.clipBoardtoolStrip.Image = null;
            this.clipBoardtoolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.clipBoardtoolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pasteSplitButton,
            this.toolStripPanelItem1});
            this.clipBoardtoolStrip.Location = new System.Drawing.Point(0, 1);
            this.clipBoardtoolStrip.Name = "clipBoardtoolStrip";
            this.clipBoardtoolStrip.Office12Mode = false;
            this.clipBoardtoolStrip.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.clipBoardtoolStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.clipBoardtoolStrip.ShowLauncher = false;
            this.clipBoardtoolStrip.Size = new System.Drawing.Size(92, 92);
            this.clipBoardtoolStrip.TabIndex = 0;
            this.clipBoardtoolStrip.Text = "Clipboard";
            // 
            // pasteSplitButton
            // 
            this.pasteSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteSplitButton.Name = "pasteSplitButton";
            this.pasteSplitButton.Size = new System.Drawing.Size(38, 76);
            this.pasteSplitButton.Text = "Paste";
            this.pasteSplitButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.pasteSplitButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.pasteSplitButton.Click += new System.EventHandler(this.pasteSplitButton_ButtonClick);
            // 
            // toolStripPanelItem1
            // 
            this.toolStripPanelItem1.CausesValidation = false;
            this.toolStripPanelItem1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.toolStripPanelItem1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cutButton,
            this.copyButton});
            this.toolStripPanelItem1.Name = "toolStripPanelItem1";
            this.toolStripPanelItem1.RowCount = 2;
            this.toolStripPanelItem1.Size = new System.Drawing.Size(43, 79);
            this.toolStripPanelItem1.Text = "toolStripPanelItem1";
            this.toolStripPanelItem1.Transparent = true;
            // 
            // cutButton
            // 
            this.cutButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.cutButton.Name = "cutButton";
            this.cutButton.Size = new System.Drawing.Size(30, 24);
            this.cutButton.Text = "Cut";
            this.cutButton.Click += new System.EventHandler(this.cutButton_Click);
            // 
            // copyButton
            // 
            this.copyButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.copyButton.Name = "copyButton";
            this.copyButton.Size = new System.Drawing.Size(39, 24);
            this.copyButton.Text = "Copy";
            this.copyButton.Click += new System.EventHandler(this.copyButton_Click);
            // 
            // fonttoolStrip
            // 
            this.fonttoolStrip.CollapsedDropDownButtonText = "Font";
            this.fonttoolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fonttoolStrip.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.fonttoolStrip.ForeColor = System.Drawing.Color.MidnightBlue;
            this.fonttoolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.fonttoolStrip.Image = null;
            this.fonttoolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fonttoolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontBasePanelItem});
            this.fonttoolStrip.Location = new System.Drawing.Point(94, 1);
            this.fonttoolStrip.Name = "fonttoolStrip";
            this.fonttoolStrip.Office12Mode = false;
            this.fonttoolStrip.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.fonttoolStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.fonttoolStrip.ShowLauncher = false;
            this.fonttoolStrip.Size = new System.Drawing.Size(239, 92);
            this.fonttoolStrip.TabIndex = 1;
            this.fonttoolStrip.Text = "Font";
            // 
            // fontBasePanelItem
            // 
            this.fontBasePanelItem.CausesValidation = false;
            this.fontBasePanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.fontBasePanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontUpperPanelItem,
            this.fontLowerPanelItem});
            this.fontBasePanelItem.Name = "fontBasePanelItem";
            this.fontBasePanelItem.Padding = new System.Windows.Forms.Padding(2, 6, 2, 2);
            this.fontBasePanelItem.RowCount = 2;
            this.fontBasePanelItem.Size = new System.Drawing.Size(228, 79);
            this.fontBasePanelItem.Text = "toolStripPanelItem3";
            this.fontBasePanelItem.Transparent = true;
            // 
            // fontUpperPanelItem
            // 
            this.fontUpperPanelItem.CausesValidation = false;
            this.fontUpperPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.fontUpperPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontComboBox,
            this.sizeComboBox,
            this.increaseFontSizeButton,
            this.decreaseFontSizeButton,
            this.toolStripSeparator1,
            this.changeCaseDropDownButton});
            this.fontUpperPanelItem.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.fontUpperPanelItem.Name = "fontUpperPanelItem";
            this.fontUpperPanelItem.Padding = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.fontUpperPanelItem.Size = new System.Drawing.Size(224, 27);
            this.fontUpperPanelItem.Text = "toolStripPanelItem2";
            this.fontUpperPanelItem.Transparent = true;
            this.fontUpperPanelItem.UseStandardLayout = true;
            // 
            // fontComboBox
            // 
            this.fontComboBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.fontComboBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            this.fontComboBox.Items.AddRange(new object[] {
            "Calibri",
            "Segoe UI",
            "Arial"});
            this.fontComboBox.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.fontComboBox.MaxLength = 32767;
            this.fontComboBox.Name = "fontComboBox";
            this.fontComboBox.Size = new System.Drawing.Size(94, 23);
            this.fontComboBox.Style = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Office2016Colorful;
            this.fontComboBox.SelectedIndexChanged += new System.EventHandler(this.fontComboBox_SelectedIndexChanged);
            // 
            // sizeComboBox
            // 
            this.sizeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sizeComboBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sizeComboBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            this.sizeComboBox.Items.AddRange(new object[] {
            "8",
            "9",
            "10",
            "11",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "24",
            "26",
            "28",
            "36",
            "48",
            "72"});
            this.sizeComboBox.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.sizeComboBox.MaxLength = 32767;
            this.sizeComboBox.Name = "sizeComboBox";
            this.sizeComboBox.Size = new System.Drawing.Size(39, 23);
            this.sizeComboBox.Style = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Office2016Colorful;
            this.sizeComboBox.SelectedIndexChanged += new System.EventHandler(this.fontComboBox_SelectedIndexChanged);
            // 
            // increaseFontSizeButton
            // 
            this.increaseFontSizeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.increaseFontSizeButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.increaseFontSizeButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.increaseFontSizeButton.Name = "increaseFontSizeButton";
            this.increaseFontSizeButton.Size = new System.Drawing.Size(23, 24);
            this.increaseFontSizeButton.Text = "toolStripButton1";
            this.increaseFontSizeButton.Click += new System.EventHandler(this.increaseFontSizeButton_Click);
            // 
            // decreaseFontSizeButton
            // 
            this.decreaseFontSizeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.decreaseFontSizeButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.decreaseFontSizeButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.decreaseFontSizeButton.Name = "decreaseFontSizeButton";
            this.decreaseFontSizeButton.Size = new System.Drawing.Size(23, 24);
            this.decreaseFontSizeButton.Text = "toolStripButton2";
            this.decreaseFontSizeButton.Click += new System.EventHandler(this.decreaseFontSizeButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(4, 24);
            // 
            // changeCaseDropDownButton
            // 
            this.changeCaseDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.changeCaseDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.upperCaseToolStripMenuItem,
            this.lowerCaseToolStripMenuItem,
            this.capitializeEachWordToolStripMenuItem});
            this.changeCaseDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.changeCaseDropDownButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.changeCaseDropDownButton.Name = "changeCaseDropDownButton";
            this.changeCaseDropDownButton.Size = new System.Drawing.Size(35, 24);
            this.changeCaseDropDownButton.Text = "toolStripDropDownButton1";
            this.changeCaseDropDownButton.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.changeCaseDropDownButton_DropDownItemClicked);
            // 
            // upperCaseToolStripMenuItem
            // 
            this.upperCaseToolStripMenuItem.Name = "upperCaseToolStripMenuItem";
            this.upperCaseToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.upperCaseToolStripMenuItem.Text = "UPPER CASE";
            // 
            // lowerCaseToolStripMenuItem
            // 
            this.lowerCaseToolStripMenuItem.Name = "lowerCaseToolStripMenuItem";
            this.lowerCaseToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.lowerCaseToolStripMenuItem.Text = "lower case";
            // 
            // capitializeEachWordToolStripMenuItem
            // 
            this.capitializeEachWordToolStripMenuItem.Name = "capitializeEachWordToolStripMenuItem";
            this.capitializeEachWordToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.capitializeEachWordToolStripMenuItem.Text = "Capitialize Each Word";
            // 
            // fontLowerPanelItem
            // 
            this.fontLowerPanelItem.CausesValidation = false;
            this.fontLowerPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.fontLowerPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.boldToolStripButton,
            this.italicToolStripButton,
            this.underlineButton,
            this.strikeThroughButton,
            this.subScriptButton,
            this.superScriptButton,
            this.toolStripSeparator3,
            this.highlightSplitButton,
            this.fontColorSplitButton});
            this.fontLowerPanelItem.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.fontLowerPanelItem.Name = "fontLowerPanelItem";
            this.fontLowerPanelItem.Padding = new System.Windows.Forms.Padding(2, 6, 2, 2);
            this.fontLowerPanelItem.Size = new System.Drawing.Size(218, 33);
            this.fontLowerPanelItem.Text = "toolStripPanelItem2";
            this.fontLowerPanelItem.Transparent = true;
            this.fontLowerPanelItem.UseStandardLayout = true;
            // 
            // boldToolStripButton
            // 
            this.boldToolStripButton.CheckOnClick = true;
            this.boldToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.boldToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.boldToolStripButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.boldToolStripButton.Name = "boldToolStripButton";
            this.boldToolStripButton.Size = new System.Drawing.Size(23, 24);
            this.boldToolStripButton.Text = "toolStripButton1";
            this.boldToolStripButton.Click += new System.EventHandler(this.boldToolStripButton_Click);
            // 
            // italicToolStripButton
            // 
            this.italicToolStripButton.CheckOnClick = true;
            this.italicToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.italicToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.italicToolStripButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.italicToolStripButton.Name = "italicToolStripButton";
            this.italicToolStripButton.Size = new System.Drawing.Size(23, 24);
            this.italicToolStripButton.Text = "toolStripButton2";
            this.italicToolStripButton.Click += new System.EventHandler(this.boldToolStripButton_Click);
            // 
            // underlineButton
            // 
            this.underlineButton.CheckOnClick = true;
            this.underlineButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.underlineButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.underlineButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.underlineButton.Name = "underlineButton";
            this.underlineButton.Size = new System.Drawing.Size(23, 24);
            this.underlineButton.Text = "toolStripButton1";
            this.underlineButton.Click += new System.EventHandler(this.boldToolStripButton_Click);
            // 
            // strikeThroughButton
            // 
            this.strikeThroughButton.CheckOnClick = true;
            this.strikeThroughButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.strikeThroughButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.strikeThroughButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.strikeThroughButton.Name = "strikeThroughButton";
            this.strikeThroughButton.Size = new System.Drawing.Size(23, 24);
            this.strikeThroughButton.Text = "toolStripButton3";
            this.strikeThroughButton.Click += new System.EventHandler(this.boldToolStripButton_Click);
            // 
            // subScriptButton
            // 
            this.subScriptButton.CheckOnClick = true;
            this.subScriptButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.subScriptButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.subScriptButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.subScriptButton.Name = "subScriptButton";
            this.subScriptButton.Size = new System.Drawing.Size(23, 24);
            this.subScriptButton.Text = "toolStripButton4";
            this.subScriptButton.Click += new System.EventHandler(this.subScriptButton_Click);
            // 
            // superScriptButton
            // 
            this.superScriptButton.CheckOnClick = true;
            this.superScriptButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.superScriptButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.superScriptButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.superScriptButton.Name = "superScriptButton";
            this.superScriptButton.Size = new System.Drawing.Size(23, 24);
            this.superScriptButton.Text = "toolStripButton5";
            this.superScriptButton.Click += new System.EventHandler(this.superScriptButton_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(4, 24);
            // 
            // highlightSplitButton
            // 
            this.highlightSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.highlightSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.highlightSplitButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.highlightSplitButton.Name = "highlightSplitButton";
            this.highlightSplitButton.Size = new System.Drawing.Size(35, 24);
            this.highlightSplitButton.Text = "toolStripSplitButton2";
            // 
            // fontColorSplitButton
            // 
            this.fontColorSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fontColorSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fontColorSplitButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.fontColorSplitButton.Name = "fontColorSplitButton";
            this.fontColorSplitButton.Size = new System.Drawing.Size(35, 24);
            this.fontColorSplitButton.Text = "toolStripSplitButton3";
            // 
            // paragraphToolStrip
            // 
            this.paragraphToolStrip.CollapsedDropDownButtonText = "Paragraph";
            this.paragraphToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.paragraphToolStrip.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.paragraphToolStrip.ForeColor = System.Drawing.Color.MidnightBlue;
            this.paragraphToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.paragraphToolStrip.Image = null;
            this.paragraphToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paragraphBasePanelItem});
            this.paragraphToolStrip.Location = new System.Drawing.Point(335, 1);
            this.paragraphToolStrip.Name = "paragraphToolStrip";
            this.paragraphToolStrip.Office12Mode = false;
            this.paragraphToolStrip.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.paragraphToolStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.paragraphToolStrip.ShowLauncher = false;
            this.paragraphToolStrip.Size = new System.Drawing.Size(100, 92);
            this.paragraphToolStrip.TabIndex = 3;
            this.paragraphToolStrip.Text = "Paragraph";
            // 
            // paragraphBasePanelItem
            // 
            this.paragraphBasePanelItem.CausesValidation = false;
            this.paragraphBasePanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.paragraphBasePanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paragraphupPanelItem,
            this.paragraphdownPanelItem});
            this.paragraphBasePanelItem.Margin = new System.Windows.Forms.Padding(1, 5, 1, 0);
            this.paragraphBasePanelItem.Name = "paragraphBasePanelItem";
            this.paragraphBasePanelItem.RowCount = 2;
            this.paragraphBasePanelItem.Size = new System.Drawing.Size(89, 74);
            this.paragraphBasePanelItem.Text = "toolStripPanelItem2";
            this.paragraphBasePanelItem.Transparent = true;
            // 
            // paragraphupPanelItem
            // 
            this.paragraphupPanelItem.CausesValidation = false;
            this.paragraphupPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.paragraphupPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bulletSplitButton,
            this.decIndentButton,
            this.incIndentButton});
            this.paragraphupPanelItem.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.paragraphupPanelItem.Name = "paragraphupPanelItem";
            this.paragraphupPanelItem.RowCount = 1;
            this.paragraphupPanelItem.Size = new System.Drawing.Size(85, 29);
            this.paragraphupPanelItem.Text = "toolStripPanelItem3";
            this.paragraphupPanelItem.Transparent = true;
            // 
            // bulletSplitButton
            // 
            this.bulletSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bulletSplitButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noneMenuItem,
            this.bulletMenuItem});
            this.bulletSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bulletSplitButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.bulletSplitButton.Name = "bulletSplitButton";
            this.bulletSplitButton.Size = new System.Drawing.Size(35, 24);
            this.bulletSplitButton.Text = "Bullets";
            this.bulletSplitButton.ButtonClick += new System.EventHandler(this.bulletSplitButton_ButtonClick);
            this.bulletSplitButton.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.bulletSplitButton_DropDownItemClicked);
            // 
            // noneMenuItem
            // 
            this.noneMenuItem.Name = "noneMenuItem";
            this.noneMenuItem.Size = new System.Drawing.Size(104, 22);
            this.noneMenuItem.Text = "None";
            // 
            // bulletMenuItem
            // 
            this.bulletMenuItem.Name = "bulletMenuItem";
            this.bulletMenuItem.Size = new System.Drawing.Size(104, 22);
            this.bulletMenuItem.Text = "Bullet";
            // 
            // decIndentButton
            // 
            this.decIndentButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.decIndentButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.decIndentButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.decIndentButton.Name = "decIndentButton";
            this.decIndentButton.Size = new System.Drawing.Size(23, 24);
            this.decIndentButton.Text = "toolStripButton2";
            this.decIndentButton.Click += new System.EventHandler(this.decIndentButton_Click);
            // 
            // incIndentButton
            // 
            this.incIndentButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.incIndentButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.incIndentButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.incIndentButton.Name = "incIndentButton";
            this.incIndentButton.Size = new System.Drawing.Size(23, 24);
            this.incIndentButton.Text = "toolStripButton1";
            this.incIndentButton.Click += new System.EventHandler(this.incIndentButton_Click);
            // 
            // paragraphdownPanelItem
            // 
            this.paragraphdownPanelItem.CausesValidation = false;
            this.paragraphdownPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.paragraphdownPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftButton,
            this.centerButton,
            this.rightButton});
            this.paragraphdownPanelItem.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.paragraphdownPanelItem.Name = "paragraphdownPanelItem";
            this.paragraphdownPanelItem.RowCount = 1;
            this.paragraphdownPanelItem.Size = new System.Drawing.Size(73, 29);
            this.paragraphdownPanelItem.Text = "toolStripPanelItem2";
            this.paragraphdownPanelItem.Transparent = true;
            // 
            // leftButton
            // 
            this.leftButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.leftButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leftButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.leftButton.Name = "leftButton";
            this.leftButton.Size = new System.Drawing.Size(23, 24);
            this.leftButton.Text = "toolStripButton1";
            this.leftButton.Click += new System.EventHandler(this.LeftButton_Click);
            // 
            // centerButton
            // 
            this.centerButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.centerButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.centerButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.centerButton.Name = "centerButton";
            this.centerButton.Size = new System.Drawing.Size(23, 24);
            this.centerButton.Text = "toolStripButton2";
            this.centerButton.Click += new System.EventHandler(this.CenterButton_Click);
            // 
            // rightButton
            // 
            this.rightButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.rightButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.rightButton.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.rightButton.Name = "rightButton";
            this.rightButton.Size = new System.Drawing.Size(23, 24);
            this.rightButton.Text = "toolStripButton3";
            this.rightButton.Click += new System.EventHandler(this.RightButton_Click);
            // 
            // toolStripEx2
            // 
            this.toolStripEx2.AutoSize = false;
            this.toolStripEx2.CollapsedDropDownButtonText = "Style";
            this.toolStripEx2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStripEx2.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.toolStripEx2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.toolStripEx2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripEx2.Image = null;
            this.toolStripEx2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripGallery1});
            this.toolStripEx2.Location = new System.Drawing.Point(437, 1);
            this.toolStripEx2.Name = "toolStripEx2";
            this.toolStripEx2.Office12Mode = false;
            this.toolStripEx2.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.toolStripEx2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripEx2.ShowLauncher = false;
            this.toolStripEx2.Size = new System.Drawing.Size(456, 92);
            this.toolStripEx2.TabIndex = 4;
            this.toolStripEx2.Text = "Style";
            // 
            // toolStripGallery1
            // 
            this.toolStripGallery1.CaptionText = "";
            this.toolStripGallery1.CheckOnClick = true;
            this.toolStripGallery1.Dimensions = new System.Drawing.Size(6, 1);
            this.toolStripGallery1.ItemBackColor = System.Drawing.Color.Empty;
            toolStripGalleryItem1.Text = "AaBbCcDd \r\n\n Normal";
            toolStripGalleryItem1.ToolTipText = "";
            toolStripGalleryItem2.Text = "AaBbCcDd \r\n\n Heading 1";
            toolStripGalleryItem2.ToolTipText = "";
            toolStripGalleryItem3.Text = "AaBbCcDd \r\n\n Heading 2";
            toolStripGalleryItem3.ToolTipText = "";
            toolStripGalleryItem4.Text = "AaBbCcDd \r\n\n Heading 3";
            toolStripGalleryItem4.ToolTipText = "";
            toolStripGalleryItem5.Text = "AaBbCcDd \r\n\n Heading 4";
            toolStripGalleryItem5.ToolTipText = "";
            toolStripGalleryItem6.Text = "AaBbCcDd \r\n\n Title";
            toolStripGalleryItem6.ToolTipText = "";
            toolStripGalleryItem7.Text = "AaBbCcDd \r\n\n Emphasis";
            toolStripGalleryItem7.ToolTipText = "";
            toolStripGalleryItem8.Text = "AaBbCcDd \r\n\n Strong";
            toolStripGalleryItem8.ToolTipText = "";
            toolStripGalleryItem9.Text = "AaBbCcDd \r\n\n Underline";
            toolStripGalleryItem9.ToolTipText = "";
            toolStripGalleryItem10.Text = "AaBbCcDd \r\n\n Italic";
            toolStripGalleryItem10.ToolTipText = "";
            this.toolStripGallery1.Items.Add(toolStripGalleryItem1);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem2);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem3);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem4);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem5);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem6);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem7);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem8);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem9);
            this.toolStripGallery1.Items.Add(toolStripGalleryItem10);
            this.toolStripGallery1.ItemSize = new System.Drawing.Size(70, 62);
            this.toolStripGallery1.Margin = new System.Windows.Forms.Padding(0, 4, 0, 1);
            this.toolStripGallery1.Name = "toolStripGallery1";
            this.toolStripGallery1.ScrollerType = Syncfusion.Windows.Forms.Tools.ToolStripGalleryScrollerType.Compact;
            this.toolStripGallery1.ShowToolTip = true;
            this.toolStripGallery1.Size = new System.Drawing.Size(447, 64);
            this.toolStripGallery1.Text = "Styles";
            this.toolStripGallery1.GalleryItemClicked += new Syncfusion.Windows.Forms.Tools.ToolStripGalleryItemEventHandler(this.toolStripGallery1_GalleryItemClicked);
            // 
            // insertTab
            // 
            this.insertTab.Name = "insertTab";
            // 
            // wordribbon.ribbonPanel2
            // 
            this.insertTab.Panel.Controls.Add(this.pagesToolStripEx);
            this.insertTab.Panel.Controls.Add(this.illustrationtoolStrip);
            this.insertTab.Panel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.insertTab.Panel.Name = "ribbonPanel2";
            this.insertTab.Panel.Padding = new System.Windows.Forms.Padding(0, 1, 15, 0);
            this.insertTab.Panel.ScrollPosition = 0;
            this.insertTab.Panel.TabIndex = 3;
            this.insertTab.Panel.Text = "Insert";
            this.insertTab.Position = 1;
            this.insertTab.Size = new System.Drawing.Size(58, 31);
            this.insertTab.Tag = "2";
            this.insertTab.Text = "Insert";
            // 
            // pagesToolStripEx
            // 
            this.pagesToolStripEx.Dock = System.Windows.Forms.DockStyle.None;
            this.pagesToolStripEx.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.pagesToolStripEx.ForeColor = System.Drawing.Color.MidnightBlue;
            this.pagesToolStripEx.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.pagesToolStripEx.Image = null;
            this.pagesToolStripEx.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.coverPageDropDownButton,
            this.blankPagetoolStripButton});
            this.pagesToolStripEx.Location = new System.Drawing.Point(0, 1);
            this.pagesToolStripEx.Name = "pagesToolStripEx";
            this.pagesToolStripEx.Office12Mode = false;
            this.pagesToolStripEx.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.pagesToolStripEx.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.pagesToolStripEx.ShowLauncher = false;
            this.pagesToolStripEx.Size = new System.Drawing.Size(150, 92);
            this.pagesToolStripEx.TabIndex = 1;
            this.pagesToolStripEx.Text = "Pages";
            // 
            // coverPageDropDownButton
            // 
            this.coverPageDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.specDesignToolStripMenuItem,
            this.reportDeisgnToolStripMenuItem,
            this.resumeToolStripMenuItem,
            this.coverLetterToolStripMenuItem});
            this.coverPageDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.coverPageDropDownButton.Name = "coverPageDropDownButton";
            this.coverPageDropDownButton.Size = new System.Drawing.Size(77, 76);
            this.coverPageDropDownButton.Text = "Cover Page";
            this.coverPageDropDownButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.coverPageDropDownButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.coverPageDropDownButton.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.coverPageDropDownButton_DropDownItemClicked);
            // 
            // specDesignToolStripMenuItem
            // 
            this.specDesignToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.specDesignToolStripMenuItem.Name = "specDesignToolStripMenuItem";
            this.specDesignToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.specDesignToolStripMenuItem.Text = "Spec Design";
            // 
            // reportDeisgnToolStripMenuItem
            // 
            this.reportDeisgnToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.reportDeisgnToolStripMenuItem.Name = "reportDeisgnToolStripMenuItem";
            this.reportDeisgnToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.reportDeisgnToolStripMenuItem.Text = "Report Deisgn";
            // 
            // resumeToolStripMenuItem
            // 
            this.resumeToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.resumeToolStripMenuItem.Name = "resumeToolStripMenuItem";
            this.resumeToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.resumeToolStripMenuItem.Text = "Resume";
            // 
            // coverLetterToolStripMenuItem
            // 
            this.coverLetterToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.coverLetterToolStripMenuItem.Name = "coverLetterToolStripMenuItem";
            this.coverLetterToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.coverLetterToolStripMenuItem.Text = "Cover Letter";
            // 
            // blankPagetoolStripButton
            // 
            this.blankPagetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.blankPagetoolStripButton.Name = "blankPagetoolStripButton";
            this.blankPagetoolStripButton.Size = new System.Drawing.Size(68, 89);
            this.blankPagetoolStripButton.Text = "Blank Page";
            this.blankPagetoolStripButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.blankPagetoolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.blankPagetoolStripButton.Click += new System.EventHandler(this.blankDocumentbutton_Click);
            // 
            // illustrationtoolStrip
            // 
            this.illustrationtoolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.illustrationtoolStrip.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.illustrationtoolStrip.ForeColor = System.Drawing.Color.MidnightBlue;
            this.illustrationtoolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.illustrationtoolStrip.Image = null;
            this.illustrationtoolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.illustrationtoolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pictureButton});
            this.illustrationtoolStrip.Location = new System.Drawing.Point(152, 1);
            this.illustrationtoolStrip.Name = "illustrationtoolStrip";
            this.illustrationtoolStrip.Office12Mode = false;
            this.illustrationtoolStrip.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.illustrationtoolStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.illustrationtoolStrip.ShowLauncher = false;
            this.illustrationtoolStrip.Size = new System.Drawing.Size(51, 92);
            this.illustrationtoolStrip.TabIndex = 0;
            this.illustrationtoolStrip.Text = "Illustration";
            // 
            // pictureButton
            // 
            this.pictureButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pictureButton.Name = "pictureButton";
            this.pictureButton.Size = new System.Drawing.Size(46, 89);
            this.pictureButton.Text = "Picture";
            this.pictureButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.pictureButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.pictureButton.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // layoutTabItem
            // 
            this.layoutTabItem.Name = "layoutTabItem";
            // 
            // wordribbon.ribbonPanel3
            // 
            this.layoutTabItem.Panel.Controls.Add(this.pageSetUptoolStrip);
            this.layoutTabItem.Panel.Controls.Add(this.toolStripEx1);
            this.layoutTabItem.Panel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.layoutTabItem.Panel.Name = "ribbonPanel3";
            this.layoutTabItem.Panel.Padding = new System.Windows.Forms.Padding(0, 1, 26, 0);
            this.layoutTabItem.Panel.ScrollPosition = 0;
            this.layoutTabItem.Panel.TabIndex = 4;
            this.layoutTabItem.Panel.Text = "Layout";
            this.layoutTabItem.Position = 2;
            this.layoutTabItem.Size = new System.Drawing.Size(63, 31);
            this.layoutTabItem.Tag = "1";
            this.layoutTabItem.Text = "Layout";
            // 
            // pageSetUptoolStrip
            // 
            this.pageSetUptoolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.pageSetUptoolStrip.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.pageSetUptoolStrip.ForeColor = System.Drawing.Color.MidnightBlue;
            this.pageSetUptoolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.pageSetUptoolStrip.Image = null;
            this.pageSetUptoolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.marginDropDownButton,
            this.orientationDropDownButton,
            this.sizeDropDownButton});
            this.pageSetUptoolStrip.Location = new System.Drawing.Point(0, 1);
            this.pageSetUptoolStrip.Name = "pageSetUptoolStrip";
            this.pageSetUptoolStrip.Office12Mode = false;
            this.pageSetUptoolStrip.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.pageSetUptoolStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.pageSetUptoolStrip.Size = new System.Drawing.Size(182, 92);
            this.pageSetUptoolStrip.TabIndex = 0;
            this.pageSetUptoolStrip.Text = "Page Setup";
            // 
            // marginDropDownButton
            // 
            this.marginDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.normalToolStripMenuItem,
            this.narrowToolStripMenuItem,
            this.moderateToolStripMenuItem,
            this.wideToolStripMenuItem});
            this.marginDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.marginDropDownButton.Name = "marginDropDownButton";
            this.marginDropDownButton.Size = new System.Drawing.Size(57, 75);
            this.marginDropDownButton.Text = "Margin";
            this.marginDropDownButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.marginDropDownButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.marginDropDownButton.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.marginDropDownButton_DropDownItemClicked);
            // 
            // normalToolStripMenuItem
            // 
            this.normalToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.normalToolStripMenuItem.Name = "normalToolStripMenuItem";
            this.normalToolStripMenuItem.Size = new System.Drawing.Size(192, 108);
            this.normalToolStripMenuItem.Text = "Normal\r\n\r\nTop:\t1” \tBottom:  1” \r\n\t\r\nLeft:\t1”\tRight:\t   1”\r\n\r\n";
            this.normalToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // narrowToolStripMenuItem
            // 
            this.narrowToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.narrowToolStripMenuItem.Name = "narrowToolStripMenuItem";
            this.narrowToolStripMenuItem.Size = new System.Drawing.Size(192, 108);
            this.narrowToolStripMenuItem.Text = "Narrow\r\n\r\nTop:\t0.5” \tBottom:    0.5” \r\n\t\r\nLeft:\t0.5”\tRight:\t   0.5”\r\n\r\n\r\n";
            // 
            // moderateToolStripMenuItem
            // 
            this.moderateToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.moderateToolStripMenuItem.Name = "moderateToolStripMenuItem";
            this.moderateToolStripMenuItem.Size = new System.Drawing.Size(192, 108);
            this.moderateToolStripMenuItem.Text = "Moderate\r\n\r\nTop:\t1” \tBottom:     1”\r\n \t\r\nLeft:\t0.75”\tRight:\t    0.75”\r\n\r\n\r\n";
            // 
            // wideToolStripMenuItem
            // 
            this.wideToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.wideToolStripMenuItem.Name = "wideToolStripMenuItem";
            this.wideToolStripMenuItem.Size = new System.Drawing.Size(192, 108);
            this.wideToolStripMenuItem.Text = "Wide\r\n\r\nTop:\t1” \tBottom:  1” \t\r\n\r\nLeft:\t2”\tRight:\t   2”\r\n\r\n\r\n";
            // 
            // orientationDropDownButton
            // 
            this.orientationDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.landscapeToolStripMenuItem,
            this.portraitToolStripMenuItem});
            this.orientationDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.orientationDropDownButton.Name = "orientationDropDownButton";
            this.orientationDropDownButton.Size = new System.Drawing.Size(80, 75);
            this.orientationDropDownButton.Text = "Orientation";
            this.orientationDropDownButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.orientationDropDownButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.orientationDropDownButton.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.orientationDropDownButton_DropDownItemClicked);
            // 
            // landscapeToolStripMenuItem
            // 
            this.landscapeToolStripMenuItem.Name = "landscapeToolStripMenuItem";
            this.landscapeToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.landscapeToolStripMenuItem.Text = "Landscape";
            // 
            // portraitToolStripMenuItem
            // 
            this.portraitToolStripMenuItem.Name = "portraitToolStripMenuItem";
            this.portraitToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.portraitToolStripMenuItem.Text = "Portrait";
            // 
            // sizeDropDownButton
            // 
            this.sizeDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.letterToolStripMenuItem,
            this.tabloidToolStripMenuItem,
            this.legalToolStripMenuItem,
            this.executiveToolStripMenuItem,
            this.a3ToolStripMenuItem,
            this.a4ToolStripMenuItem});
            this.sizeDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.sizeDropDownButton.Name = "sizeDropDownButton";
            this.sizeDropDownButton.Size = new System.Drawing.Size(40, 89);
            this.sizeDropDownButton.Text = "Size";
            this.sizeDropDownButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.sizeDropDownButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.sizeDropDownButton.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.sizeDropDownButton_DropDownItemClicked);
            // 
            // letterToolStripMenuItem
            // 
            this.letterToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.letterToolStripMenuItem.Name = "letterToolStripMenuItem";
            this.letterToolStripMenuItem.Size = new System.Drawing.Size(147, 56);
            this.letterToolStripMenuItem.Text = "Letter\r\n8.5” x 11”\r\n";
            // 
            // tabloidToolStripMenuItem
            // 
            this.tabloidToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tabloidToolStripMenuItem.Name = "tabloidToolStripMenuItem";
            this.tabloidToolStripMenuItem.Size = new System.Drawing.Size(147, 56);
            this.tabloidToolStripMenuItem.Text = "Tabloid\r\n11” x 17”\r\n";
            // 
            // legalToolStripMenuItem
            // 
            this.legalToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.legalToolStripMenuItem.Name = "legalToolStripMenuItem";
            this.legalToolStripMenuItem.Size = new System.Drawing.Size(147, 56);
            this.legalToolStripMenuItem.Text = "Legal\r\n8.5” x 14”\r\n";
            // 
            // executiveToolStripMenuItem
            // 
            this.executiveToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.executiveToolStripMenuItem.Name = "executiveToolStripMenuItem";
            this.executiveToolStripMenuItem.Size = new System.Drawing.Size(147, 56);
            this.executiveToolStripMenuItem.Text = "Executive\r\n7.25” x 10.5”\r\n";
            // 
            // a3ToolStripMenuItem
            // 
            this.a3ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.a3ToolStripMenuItem.Name = "a3ToolStripMenuItem";
            this.a3ToolStripMenuItem.Size = new System.Drawing.Size(147, 56);
            this.a3ToolStripMenuItem.Text = "A3\r\n11.69” x 16.53”\r\n";
            // 
            // a4ToolStripMenuItem
            // 
            this.a4ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.a4ToolStripMenuItem.Name = "a4ToolStripMenuItem";
            this.a4ToolStripMenuItem.Size = new System.Drawing.Size(147, 56);
            this.a4ToolStripMenuItem.Text = "A4\r\n\r\n8.27” X 11.69 “\r\n";
            // 
            // toolStripEx1
            // 
            this.toolStripEx1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStripEx1.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.toolStripEx1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.toolStripEx1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripEx1.Image = null;
            this.toolStripEx1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.indentPanelItem});
            this.toolStripEx1.Location = new System.Drawing.Point(184, 1);
            this.toolStripEx1.Name = "toolStripEx1";
            this.toolStripEx1.Office12Mode = false;
            this.toolStripEx1.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.toolStripEx1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripEx1.Size = new System.Drawing.Size(87, 92);
            this.toolStripEx1.TabIndex = 1;
            this.toolStripEx1.Text = "Paragraph";
            // 
            // indentPanelItem
            // 
            this.indentPanelItem.CausesValidation = false;
            this.indentPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.indentPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.indentLabel,
            this.leftPanelItem,
            this.rightPanelItem});
            this.indentPanelItem.Name = "indentPanelItem";
            this.indentPanelItem.Padding = new System.Windows.Forms.Padding(2, 0, 2, 2);
            this.indentPanelItem.Size = new System.Drawing.Size(80, 70);
            this.indentPanelItem.Text = "toolStripPanelItem2";
            this.indentPanelItem.Transparent = true;
            // 
            // indentLabel
            // 
            this.indentLabel.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.indentLabel.Name = "indentLabel";
            this.indentLabel.Size = new System.Drawing.Size(41, 15);
            this.indentLabel.Text = "Indent";
            // 
            // leftPanelItem
            // 
            this.leftPanelItem.CausesValidation = false;
            this.leftPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.leftPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftLabel});
            this.leftPanelItem.Margin = new System.Windows.Forms.Padding(1, 2, 1, 0);
            this.leftPanelItem.Name = "leftPanelItem";
            this.leftPanelItem.Size = new System.Drawing.Size(72, 25);
            this.leftPanelItem.Text = "toolStripPanelItem";
            this.leftPanelItem.Transparent = true;
            this.leftPanelItem.UseStandardLayout = true;
            // 
            // leftLabel
            // 
            this.leftLabel.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.leftLabel.Name = "leftLabel";
            this.leftLabel.Size = new System.Drawing.Size(66, 15);
            this.leftLabel.Text = "Left             ";
            // 
            // rightPanelItem
            // 
            this.rightPanelItem.CausesValidation = false;
            this.rightPanelItem.ForeColor = System.Drawing.Color.MidnightBlue;
            this.rightPanelItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rightLabel});
            this.rightPanelItem.Name = "rightPanelItem";
            this.rightPanelItem.Size = new System.Drawing.Size(74, 25);
            this.rightPanelItem.Text = "toolStripPanelItem3";
            this.rightPanelItem.Transparent = true;
            this.rightPanelItem.UseStandardLayout = true;
            // 
            // rightLabel
            // 
            this.rightLabel.Margin = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.rightLabel.Name = "rightLabel";
            this.rightLabel.Size = new System.Drawing.Size(68, 15);
            this.rightLabel.Text = "Right           ";
            // 
            // recenttreeMenuItem
            // 
            this.recenttreeMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.recenttreeMenuItem.ItemBackColor = System.Drawing.SystemColors.Control;
            this.recenttreeMenuItem.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(225)))), ((int)(((byte)(242)))));
            this.recenttreeMenuItem.Location = new System.Drawing.Point(0, 0);
            this.recenttreeMenuItem.Name = "recenttreeMenuItem";
            this.recenttreeMenuItem.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(213)))), ((int)(((byte)(242)))));
            this.recenttreeMenuItem.Size = new System.Drawing.Size(229, 50);
            this.recenttreeMenuItem.TabIndex = 0;
            this.recenttreeMenuItem.Text = "Recent";
            // 
            // thisPCtreeMenuItem
            // 
            this.thisPCtreeMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.thisPCtreeMenuItem.ItemBackColor = System.Drawing.SystemColors.Control;
            this.thisPCtreeMenuItem.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(225)))), ((int)(((byte)(242)))));
            this.thisPCtreeMenuItem.Location = new System.Drawing.Point(0, 52);
            this.thisPCtreeMenuItem.Name = "thisPCtreeMenuItem";
            this.thisPCtreeMenuItem.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(213)))), ((int)(((byte)(242)))));
            this.thisPCtreeMenuItem.Size = new System.Drawing.Size(229, 50);
            this.thisPCtreeMenuItem.TabIndex = 0;
            this.thisPCtreeMenuItem.Text = "This PC";
            // 
            // SaveAsPCtreeMenuItem
            // 
            this.SaveAsPCtreeMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.SaveAsPCtreeMenuItem.ItemBackColor = System.Drawing.SystemColors.Control;
            this.SaveAsPCtreeMenuItem.Location = new System.Drawing.Point(0, 0);
            this.SaveAsPCtreeMenuItem.Name = "SaveAsPCtreeMenuItem";
            this.SaveAsPCtreeMenuItem.Size = new System.Drawing.Size(257, 50);
            this.SaveAsPCtreeMenuItem.TabIndex = 0;
            this.SaveAsPCtreeMenuItem.Text = "This PC";
            // 
            // saveAsToppanel
            // 
            this.saveAsToppanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.saveAsToppanel.Controls.Add(this.label1);
            this.saveAsToppanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.saveAsToppanel.Location = new System.Drawing.Point(0, 0);
            this.saveAsToppanel.Name = "saveAsToppanel";
            this.saveAsToppanel.Size = new System.Drawing.Size(895, 80);
            this.saveAsToppanel.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Save As";
            // 
            // imageToolStripMenuItem
            // 
            this.imageToolStripMenuItem.Name = "imageToolStripMenuItem";
            this.imageToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.imageToolStripMenuItem.Text = "image";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.pasteToolStripMenuItem.Text = "Paste Special";
            // 
            // pasteSpecialToolStripMenuItem
            // 
            this.pasteSpecialToolStripMenuItem.Name = "pasteSpecialToolStripMenuItem";
            this.pasteSpecialToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.pasteSpecialToolStripMenuItem.Text = "Set Default Paste";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Location = new System.Drawing.Point(162, 19);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(674, 388);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // sentenceCaseToolStripMenuItem
            // 
            this.sentenceCaseToolStripMenuItem.Name = "sentenceCaseToolStripMenuItem";
            this.sentenceCaseToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.sentenceCaseToolStripMenuItem.Text = "Sentence case";
            // 
            // rtbpanel
            // 
            this.rtbpanel.Controls.Add(this.richTextBox1);
            this.rtbpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbpanel.Location = new System.Drawing.Point(1, 160);
            this.rtbpanel.Name = "rtbpanel";
            this.rtbpanel.Size = new System.Drawing.Size(1032, 421);
            this.rtbpanel.TabIndex = 5;
            // 
            // statusStripEx1
            // 
            this.statusStripEx1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.statusStripEx1.BeforeTouchSize = new System.Drawing.Size(1032, 22);
            this.statusStripEx1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStripEx1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trackBarItem1,
            this.statusStripLabel1,
            this.statusStripLabel2});
            this.statusStripEx1.Location = new System.Drawing.Point(1, 581);
            this.statusStripEx1.MetroColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(206)))), ((int)(((byte)(255)))));
            this.statusStripEx1.Name = "statusStripEx1";
            this.statusStripEx1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStripEx1.ShowSeparator = false;
            this.statusStripEx1.Size = new System.Drawing.Size(1032, 22);
            this.statusStripEx1.TabIndex = 6;
            this.statusStripEx1.Text = "statusStripEx1";
            this.statusStripEx1.ThemeName = "Office2016Colorful";
            this.statusStripEx1.VisualStyle = Syncfusion.Windows.Forms.Tools.StatusStripExStyle.Office2016Colorful;
            // 
            // trackBarItem1
            // 
            this.trackBarItem1.Maximum = 10;
            this.trackBarItem1.Name = "trackBarItem1";
            this.trackBarItem1.Size = new System.Drawing.Size(188, 20);
            this.trackBarItem1.Text = "trackBarItem1";
            this.trackBarItem1.Value = 5;
            // 
            // statusStripLabel1
            // 
            this.statusStripLabel1.Margin = new System.Windows.Forms.Padding(0, 4, 0, 2);
            this.statusStripLabel1.Name = "statusStripLabel1";
            this.statusStripLabel1.Size = new System.Drawing.Size(65, 15);
            this.statusStripLabel1.Text = "Page 1 of 1";
            // 
            // statusStripLabel2
            // 
            this.statusStripLabel2.Margin = new System.Windows.Forms.Padding(0, 4, 0, 2);
            this.statusStripLabel2.Name = "statusStripLabel2";
            this.statusStripLabel2.Size = new System.Drawing.Size(122, 15);
            this.statusStripLabel2.Text = "English(United States)";
            // 
            // imageListAdv1
            // 
            dpiAwareImage1.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage1.DPI120Image")));
            dpiAwareImage1.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage1.DPI144Image")));
            dpiAwareImage1.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage1.DPI192Image")));
            dpiAwareImage1.Index = 0;
            dpiAwareImage2.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage2.DPI120Image")));
            dpiAwareImage2.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage2.DPI144Image")));
            dpiAwareImage2.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage2.DPI192Image")));
            dpiAwareImage2.Index = 1;
            dpiAwareImage3.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage3.DPI120Image")));
            dpiAwareImage3.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage3.DPI144Image")));
            dpiAwareImage3.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage3.DPI192Image")));
            dpiAwareImage3.Index = 2;
            dpiAwareImage4.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage4.DPI120Image")));
            dpiAwareImage4.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage4.DPI144Image")));
            dpiAwareImage4.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage4.DPI192Image")));
            dpiAwareImage4.Index = 3;
            dpiAwareImage5.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage5.DPI120Image")));
            dpiAwareImage5.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage5.DPI144Image")));
            dpiAwareImage5.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage5.DPI192Image")));
            dpiAwareImage5.Index = 4;
            dpiAwareImage6.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage6.DPI120Image")));
            dpiAwareImage6.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage6.DPI144Image")));
            dpiAwareImage6.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage6.DPI192Image")));
            dpiAwareImage6.Index = 5;
            dpiAwareImage7.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage7.DPI120Image")));
            dpiAwareImage7.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage7.DPI144Image")));
            dpiAwareImage7.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage7.DPI192Image")));
            dpiAwareImage7.Index = 6;
            dpiAwareImage8.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage8.DPI120Image")));
            dpiAwareImage8.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage8.DPI144Image")));
            dpiAwareImage8.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage8.DPI192Image")));
            dpiAwareImage8.Index = 7;
            dpiAwareImage9.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage9.DPI120Image")));
            dpiAwareImage9.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage9.DPI144Image")));
            dpiAwareImage9.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage9.DPI192Image")));
            dpiAwareImage9.Index = 8;
            dpiAwareImage10.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage10.DPI120Image")));
            dpiAwareImage10.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage10.DPI144Image")));
            dpiAwareImage10.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage10.DPI192Image")));
            dpiAwareImage10.Index = 9;
            dpiAwareImage11.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage11.DPI120Image")));
            dpiAwareImage11.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage11.DPI144Image")));
            dpiAwareImage11.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage11.DPI192Image")));
            dpiAwareImage11.Index = 10;
            dpiAwareImage12.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage12.DPI120Image")));
            dpiAwareImage12.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage12.DPI144Image")));
            dpiAwareImage12.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage12.DPI192Image")));
            dpiAwareImage12.Index = 11;
            dpiAwareImage13.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage13.DPI120Image")));
            dpiAwareImage13.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage13.DPI144Image")));
            dpiAwareImage13.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage13.DPI192Image")));
            dpiAwareImage13.Index = 12;
            dpiAwareImage14.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage14.DPI120Image")));
            dpiAwareImage14.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage14.DPI144Image")));
            dpiAwareImage14.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage14.DPI192Image")));
            dpiAwareImage14.Index = 13;
            dpiAwareImage15.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage15.DPI120Image")));
            dpiAwareImage15.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage15.DPI144Image")));
            dpiAwareImage15.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage15.DPI192Image")));
            dpiAwareImage15.Index = 14;
            dpiAwareImage16.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage16.DPI120Image")));
            dpiAwareImage16.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage16.DPI144Image")));
            dpiAwareImage16.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage16.DPI192Image")));
            dpiAwareImage16.Index = 15;
            dpiAwareImage17.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage17.DPI120Image")));
            dpiAwareImage17.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage17.DPI144Image")));
            dpiAwareImage17.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage17.DPI192Image")));
            dpiAwareImage17.Index = 16;
            dpiAwareImage18.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage18.DPI120Image")));
            dpiAwareImage18.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage18.DPI144Image")));
            dpiAwareImage18.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage18.DPI192Image")));
            dpiAwareImage18.Index = 17;
            dpiAwareImage19.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage19.DPI120Image")));
            dpiAwareImage19.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage19.DPI144Image")));
            dpiAwareImage19.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage19.DPI192Image")));
            dpiAwareImage19.Index = 18;
            dpiAwareImage20.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage20.DPI120Image")));
            dpiAwareImage20.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage20.DPI144Image")));
            dpiAwareImage20.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage20.DPI192Image")));
            dpiAwareImage20.Index = 19;
            dpiAwareImage21.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage21.DPI120Image")));
            dpiAwareImage21.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage21.DPI144Image")));
            dpiAwareImage21.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage21.DPI192Image")));
            dpiAwareImage21.Index = 20;
            dpiAwareImage22.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage22.DPI120Image")));
            dpiAwareImage22.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage22.DPI144Image")));
            dpiAwareImage22.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage22.DPI192Image")));
            dpiAwareImage22.Index = 21;
            dpiAwareImage23.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage23.DPI120Image")));
            dpiAwareImage23.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage23.DPI144Image")));
            dpiAwareImage23.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage23.DPI192Image")));
            dpiAwareImage23.Index = 22;
            dpiAwareImage24.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage24.DPI120Image")));
            dpiAwareImage24.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage24.DPI144Image")));
            dpiAwareImage24.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage24.DPI192Image")));
            dpiAwareImage24.Index = 23;
            dpiAwareImage25.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage25.DPI120Image")));
            dpiAwareImage25.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage25.DPI144Image")));
            dpiAwareImage25.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage25.DPI192Image")));
            dpiAwareImage25.Index = 24;
            dpiAwareImage26.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage26.DPI120Image")));
            dpiAwareImage26.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage26.DPI144Image")));
            dpiAwareImage26.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage26.DPI192Image")));
            dpiAwareImage26.Index = 25;
            dpiAwareImage27.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage27.DPI120Image")));
            dpiAwareImage27.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage27.DPI144Image")));
            dpiAwareImage27.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage27.DPI192Image")));
            dpiAwareImage27.Index = 26;
            dpiAwareImage28.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage28.DPI120Image")));
            dpiAwareImage28.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage28.DPI144Image")));
            dpiAwareImage28.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage28.DPI192Image")));
            dpiAwareImage28.Index = 27;
            dpiAwareImage29.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage29.DPI120Image")));
            dpiAwareImage29.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage29.DPI144Image")));
            dpiAwareImage29.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage29.DPI192Image")));
            dpiAwareImage29.Index = 28;
            dpiAwareImage30.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage30.DPI120Image")));
            dpiAwareImage30.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage30.DPI144Image")));
            dpiAwareImage30.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage30.DPI192Image")));
            dpiAwareImage30.Index = 29;
            dpiAwareImage31.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage31.DPI120Image")));
            dpiAwareImage31.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage31.DPI144Image")));
            dpiAwareImage31.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage31.DPI192Image")));
            dpiAwareImage31.Index = 30;
            dpiAwareImage32.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage32.DPI120Image")));
            dpiAwareImage32.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage32.DPI144Image")));
            dpiAwareImage32.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage32.DPI192Image")));
            dpiAwareImage32.Index = 31;
            dpiAwareImage33.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage33.DPI120Image")));
            dpiAwareImage33.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage33.DPI144Image")));
            dpiAwareImage33.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage33.DPI192Image")));
            dpiAwareImage33.Index = 32;
            dpiAwareImage34.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage34.DPI120Image")));
            dpiAwareImage34.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage34.DPI144Image")));
            dpiAwareImage34.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage34.DPI192Image")));
            dpiAwareImage34.Index = 33;
            dpiAwareImage35.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage35.DPI120Image")));
            dpiAwareImage35.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage35.DPI144Image")));
            dpiAwareImage35.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage35.DPI192Image")));
            dpiAwareImage35.Index = 34;
            dpiAwareImage36.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage36.DPI120Image")));
            dpiAwareImage36.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage36.DPI144Image")));
            dpiAwareImage36.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage36.DPI192Image")));
            dpiAwareImage36.Index = 35;
            dpiAwareImage37.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage37.DPI120Image")));
            dpiAwareImage37.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage37.DPI144Image")));
            dpiAwareImage37.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage37.DPI192Image")));
            dpiAwareImage37.Index = 36;
            dpiAwareImage38.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage38.DPI120Image")));
            dpiAwareImage38.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage38.DPI144Image")));
            dpiAwareImage38.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage38.DPI192Image")));
            dpiAwareImage38.Index = 37;
            dpiAwareImage39.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage39.DPI120Image")));
            dpiAwareImage39.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage39.DPI144Image")));
            dpiAwareImage39.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage39.DPI192Image")));
            dpiAwareImage39.Index = 38;
            dpiAwareImage40.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage40.DPI120Image")));
            dpiAwareImage40.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage40.DPI144Image")));
            dpiAwareImage40.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage40.DPI192Image")));
            dpiAwareImage40.Index = 39;
            dpiAwareImage41.DPI120Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage41.DPI120Image")));
            dpiAwareImage41.DPI144Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage41.DPI144Image")));
            dpiAwareImage41.DPI192Image = ((System.Drawing.Image)(resources.GetObject("dpiAwareImage41.DPI192Image")));
            dpiAwareImage41.Index = 40;
            this.imageListAdv1.DPIImages.AddRange(new Syncfusion.Windows.Forms.Tools.DPIAwareImage[] {
            dpiAwareImage1,
            dpiAwareImage2,
            dpiAwareImage3,
            dpiAwareImage4,
            dpiAwareImage5,
            dpiAwareImage6,
            dpiAwareImage7,
            dpiAwareImage8,
            dpiAwareImage9,
            dpiAwareImage10,
            dpiAwareImage11,
            dpiAwareImage12,
            dpiAwareImage13,
            dpiAwareImage14,
            dpiAwareImage15,
            dpiAwareImage16,
            dpiAwareImage17,
            dpiAwareImage18,
            dpiAwareImage19,
            dpiAwareImage20,
            dpiAwareImage21,
            dpiAwareImage22,
            dpiAwareImage23,
            dpiAwareImage24,
            dpiAwareImage25,
            dpiAwareImage26,
            dpiAwareImage27,
            dpiAwareImage28,
            dpiAwareImage29,
            dpiAwareImage30,
            dpiAwareImage31,
            dpiAwareImage32,
            dpiAwareImage33,
            dpiAwareImage34,
            dpiAwareImage35,
            dpiAwareImage36,
            dpiAwareImage37,
            dpiAwareImage38,
            dpiAwareImage39,
            dpiAwareImage40,
            dpiAwareImage41});
            this.imageListAdv1.Images.AddRange(new System.Drawing.Image[] {
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images1"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images2"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images3"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images4"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images5"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images6"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images7"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images8"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images9"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images10"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images11"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images12"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images13"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images14"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images15"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images16"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images17"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images18"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images19"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images20"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images21"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images22"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images23"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images24"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images25"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images26"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images27"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images28"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images29"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images30"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images31"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images32"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images33"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images34"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images35"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images36"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images37"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images38"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images39"))),
            ((System.Drawing.Image)(resources.GetObject("imageListAdv1.Images40")))});
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 604);
            this.Controls.Add(this.backStage1);
            this.Controls.Add(this.statusStripEx1);
            this.Controls.Add(this.rtbpanel);
            this.Controls.Add(this.wordribbon);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(1, 0, 1, 1);
            this.ShowApplicationIcon = false;
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.wordribbon)).EndInit();
            this.wordribbon.ResumeLayout(false);
            this.wordribbon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backStage1)).EndInit();
            this.backStage1.ResumeLayout(false);
            this.infobackStageTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.homeTab.Panel.ResumeLayout(false);
            this.homeTab.Panel.PerformLayout();
            this.clipBoardtoolStrip.ResumeLayout(false);
            this.clipBoardtoolStrip.PerformLayout();
            this.fonttoolStrip.ResumeLayout(false);
            this.fonttoolStrip.PerformLayout();
            this.paragraphToolStrip.ResumeLayout(false);
            this.paragraphToolStrip.PerformLayout();
            this.toolStripEx2.ResumeLayout(false);
            this.toolStripEx2.PerformLayout();
            this.insertTab.Panel.ResumeLayout(false);
            this.insertTab.Panel.PerformLayout();
            this.pagesToolStripEx.ResumeLayout(false);
            this.pagesToolStripEx.PerformLayout();
            this.illustrationtoolStrip.ResumeLayout(false);
            this.illustrationtoolStrip.PerformLayout();
            this.layoutTabItem.Panel.ResumeLayout(false);
            this.layoutTabItem.Panel.PerformLayout();
            this.pageSetUptoolStrip.ResumeLayout(false);
            this.pageSetUptoolStrip.PerformLayout();
            this.toolStripEx1.ResumeLayout(false);
            this.toolStripEx1.PerformLayout();
            this.saveAsToppanel.ResumeLayout(false);
            this.saveAsToppanel.PerformLayout();
            this.rtbpanel.ResumeLayout(false);
            this.statusStripEx1.ResumeLayout(false);
            this.statusStripEx1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

     

        #endregion

        private Syncfusion.Windows.Forms.Tools.RibbonControlAdv wordribbon;
        private Syncfusion.Windows.Forms.Tools.ToolStripTabItem homeTab;
        private Syncfusion.Windows.Forms.Tools.ToolStripTabItem insertTab;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx clipBoardtoolStrip;
        private System.Windows.Forms.ToolStripButton pasteSplitButton;
        private System.Windows.Forms.ToolStripMenuItem imageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteSpecialToolStripMenuItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem toolStripPanelItem1;
        private System.Windows.Forms.ToolStripButton cutButton;
        private System.Windows.Forms.ToolStripButton copyButton;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx fonttoolStrip;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem fontUpperPanelItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx fontComboBox;
        private Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx sizeComboBox;
        private System.Windows.Forms.ToolStripButton increaseFontSizeButton;
        private System.Windows.Forms.ToolStripButton decreaseFontSizeButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton changeCaseDropDownButton;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem fontBasePanelItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem fontLowerPanelItem;
        private System.Windows.Forms.ToolStripButton boldToolStripButton;
        private System.Windows.Forms.ToolStripButton italicToolStripButton;
        private System.Windows.Forms.ToolStripButton strikeThroughButton;
        private System.Windows.Forms.ToolStripButton subScriptButton;
        private System.Windows.Forms.ToolStripButton superScriptButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSplitButton highlightSplitButton;
        private System.Windows.Forms.ToolStripSplitButton fontColorSplitButton;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx illustrationtoolStrip;
        private System.Windows.Forms.ToolStripButton pictureButton;
        private Syncfusion.Windows.Forms.BackStageView backStageView1;
        private Syncfusion.Windows.Forms.BackStage backStage1;
        private Syncfusion.Windows.Forms.BackStageTab infobackStageTab;
        private Syncfusion.Windows.Forms.BackStageSeparator backStageSeparator1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private Syncfusion.Windows.Forms.BackStageTab openbackStageTab;
        private Syncfusion.Windows.Forms.BackStageButton savebackStageTab;
        private Syncfusion.Windows.Forms.BackStageTab saveAsbackStageTab;
        private Syncfusion.Windows.Forms.BackStageTab printbackStageTab;
        private Syncfusion.Windows.Forms.Tools.TreeMenuItem recenttreeMenuItem;
        private Syncfusion.Windows.Forms.Tools.TreeMenuItem thisPCtreeMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label documentLabel;
        private System.Windows.Forms.Label lastAccessValueLabel;
        private System.Windows.Forms.Label lengthvaluelabel;
        private System.Windows.Forms.Label createdTimeValuelabel;
        private System.Windows.Forms.Label lastAccessTimeLabel;
        private System.Windows.Forms.Label createdTimelabel;
        private System.Windows.Forms.Label sizevaluelabel;
        private System.Windows.Forms.Label sizelabel;
        private Syncfusion.Windows.Forms.Tools.TreeMenuItem SaveAsPCtreeMenuItem;
        private System.Windows.Forms.Panel saveAsToppanel;
        private System.Windows.Forms.Label label1;
        private Syncfusion.Windows.Forms.BackStageButton closebackStageButton;
        private System.Windows.Forms.ToolStripMenuItem upperCaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowerCaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sentenceCaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem capitializeEachWordToolStripMenuItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx paragraphToolStrip;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem paragraphBasePanelItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem paragraphupPanelItem;
        private System.Windows.Forms.ToolStripSplitButton bulletSplitButton;
        private System.Windows.Forms.ToolStripButton incIndentButton;
        private System.Windows.Forms.ToolStripButton decIndentButton;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem paragraphdownPanelItem;
        private System.Windows.Forms.ToolStripButton leftButton;
        private System.Windows.Forms.ToolStripButton centerButton;
        private System.Windows.Forms.ToolStripButton rightButton;
        private Syncfusion.Windows.Forms.Tools.ToolStripTabItem layoutTabItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx pageSetUptoolStrip;
        private System.Windows.Forms.ToolStripDropDownButton marginDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem normalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem narrowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moderateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wideToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton orientationDropDownButton;
        private System.Windows.Forms.ToolStripDropDownButton sizeDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem landscapeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem portraitToolStripMenuItem;
        private System.Windows.Forms.Panel rtbpanel;
        private System.Windows.Forms.ToolStripMenuItem letterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabloidToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem legalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem executiveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem a3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem a4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noneMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bulletMenuItem;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx pagesToolStripEx;
        private System.Windows.Forms.ToolStripButton blankPagetoolStripButton;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx toolStripEx1;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem indentPanelItem;
        private System.Windows.Forms.ToolStripLabel indentLabel;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem leftPanelItem;
        private System.Windows.Forms.ToolStripLabel leftLabel;
        private Syncfusion.Windows.Forms.Tools.ToolStripPanelItem rightPanelItem;
        private System.Windows.Forms.ToolStripLabel rightLabel;
        private System.Windows.Forms.ToolStripDropDownButton coverPageDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem specDesignToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportDeisgnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coverLetterToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton underlineButton;
        private Syncfusion.Windows.Forms.Tools.StatusStripEx statusStripEx1;
        private Syncfusion.Windows.Forms.Tools.TrackBarItem trackBarItem1;
        private Syncfusion.Windows.Forms.Tools.StatusStripLabel statusStripLabel1;
        private Syncfusion.Windows.Forms.Tools.StatusStripLabel statusStripLabel2;
        private Syncfusion.Windows.Forms.Tools.ToolStripEx toolStripEx2;
        private Syncfusion.Windows.Forms.Tools.ToolStripGallery toolStripGallery1;
        private Syncfusion.Windows.Forms.Tools.ImageListAdv imageListAdv1;
        private Syncfusion.Windows.Forms.BackStageTab backStageTab1;
        private Syncfusion.Windows.Forms.BackStageButton backStageButton1;
    }
}

