using Microsoft.Win32;
using Syncfusion.Windows.Forms.Tools;
using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WF_Word
{
    public partial class Form1 : RibbonForm
    {
        #region Fields

        /// <summary>
        /// ColorPicker to update the highlighted text.
        /// </summary>
        ColorPickerUIAdv colorpicker1 = new ColorPickerUIAdv();

        /// <summary>
        /// ColorPicker to update the text color.
        /// </summary>
        ColorPickerUIAdv colorpicker2 = new ColorPickerUIAdv();

        /// <summary>
        /// To update the left indentation of the selected text.
        /// </summary>
        NumericUpDownExt leftNumeric = new NumericUpDownExt();

        /// <summary>
        /// To update the right indentation of the selected text.
        /// </summary>
        NumericUpDownExt rightNumeric = new NumericUpDownExt();

        /// <summary>
        /// Holds the selected font index.
        /// </summary>
        int storedfontindex = 0;

        /// <summary>
        /// Holds the selected size index.
        /// </summary>
        int storedsizeindex = 0;

        /// <summary>
        /// Stores the value to update the indentation of the selected text.
        /// </summary>
        int indentText;

        /// <summary>
        /// Stores the size of the RichTextBox panel.
        /// </summary>
        Size savedsize = Size.Empty;

        /// <summary>
        /// Stores the location of the RichTextBox panel.
        /// </summary>
        Point savedLocation = Point.Empty;

        /// <summary>
        /// Stores the previously selected orientation of the RichTextBox.
        /// </summary>
        ToolStripItem lastclickedItem;

        /// <summary>
        /// Stores the previously selected margin of the RichTextBox.
        /// </summary>
        ToolStripItem lastclickedmarginItem;

        /// <summary>
        /// Stores the previously selected size of the RichTextBox.
        /// </summary>
        ToolStripItem lastclickedsizeItem;
        #endregion

        #region Form Constructor

        /// <summary>
        /// Form Constructor 
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            this.backStage1.VisibleFullText = true;
            this.sizeComboBox.Validated += SizeComboBox_Validated;
            this.fontComboBox.Validated += FontComboBox_Validated;
            this.richTextBox1.LoadFile("..//..//Resources/Documents/temp.rtf");
            InfoTabLabelUpdate("..//..//Resources/Documents/temp.rtf");
            this.rtbpanel.AutoScroll = true;
            this.rtbpanel.Dock = DockStyle.Fill;
            this.richTextBox1.Height = 1600;
            this.trackBarItem1.TrackBarExControl.Style = TrackBarEx.Theme.Office2016Colorful;
            this.WindowState = FormWindowState.Maximized;
            foreach (FontFamily oneFontFamily in FontFamily.Families)
            {
                fontComboBox.Items.Add(oneFontFamily.Name);
            }
            sizeComboBox.Text = this.richTextBox1.Font.Size.ToString();
            fontComboBox.Text = this.richTextBox1.Font.FontFamily.Name;
            fontComboBox.ComboBox.TextBox.SelectionStart = 0;
            this.colorpicker1.Picked += Colorpicker1_Picked;
            this.colorpicker2.Picked += Colorpicker2_Picked;
            ToolStripButton saveItem = new ToolStripButton(imageListAdv1.Images[22]);
            QuickButtonReflectable quick = new QuickButtonReflectable(saveItem);
            this.wordribbon.Header.AddQuickItem(quick);
            this.wordribbon.TouchMode = true;
            indentText = this.richTextBox1.SelectionIndent;
            this.wordribbon.MenuColor = ColorTranslator.FromHtml("#2a579a");
            richTextBox1.SelectionStart = 0;
            richTextBox1.SelectedText = "\n\n";
            richTextBox1.SelectAll();
            richTextBox1.SelectionIndent = 50;
            richTextBox1.SelectionRightIndent = 50;
            richTextBox1.SelectionLength = 0;
            richTextBox1.DeselectAll();
            this.wordribbon.QuickPanelVisible = true;
            this.wordribbon.ThemeName = "Office2019Colorful";
            this.colorpicker1.ThemeName = "Office2019Colorful";
            this.colorpicker2.ThemeName = "Office2019Colorful";
            this.Load += Form1_Load;
            pasteSplitButton.Image = imageListAdv1.Images[4];
            cutButton.Image = imageListAdv1.Images[13];
            copyButton.Image = imageListAdv1.Images[12];
            boldToolStripButton.Image = imageListAdv1.Images[10];
            italicToolStripButton.Image = imageListAdv1.Images[19];
            underlineButton.Image = imageListAdv1.Images[28];
            strikeThroughButton.Image = imageListAdv1.Images[24];
            subScriptButton.Image = imageListAdv1.Images[25];
            superScriptButton.Image = imageListAdv1.Images[26];
            highlightSplitButton.Image = imageListAdv1.Images[27];
            fontColorSplitButton.Image = imageListAdv1.Images[15];
            coverPageDropDownButton.Image = imageListAdv1.Images[1];
            blankPagetoolStripButton.Image = imageListAdv1.Images[0];
            pictureButton.Image = imageListAdv1.Images[5];
            marginDropDownButton.Image = imageListAdv1.Images[2];
            orientationDropDownButton.Image = imageListAdv1.Images[3];
            sizeDropDownButton.Image = imageListAdv1.Images[6];
            leftLabel.Image = imageListAdv1.Images[14];
            rightLabel.Image = imageListAdv1.Images[21];
            increaseFontSizeButton.Image = imageListAdv1.Images[17];
            decreaseFontSizeButton.Image = imageListAdv1.Images[23];
            changeCaseDropDownButton.Image = imageListAdv1.Images[11];
            bulletSplitButton.Image = imageListAdv1.Images[20];
            incIndentButton.Image = imageListAdv1.Images[18];
            decIndentButton.Image = imageListAdv1.Images[14];
            leftButton.Image = imageListAdv1.Images[7];
            centerButton.Image = imageListAdv1.Images[8];
            rightButton.Image = imageListAdv1.Images[9];
            specDesignToolStripMenuItem.Image = imageListAdv1.Images[38];
            reportDeisgnToolStripMenuItem.Image = imageListAdv1.Images[36];
            resumeToolStripMenuItem.Image = imageListAdv1.Images[37];
            coverLetterToolStripMenuItem.Image = imageListAdv1.Images[30];
            normalToolStripMenuItem.Image = imageListAdv1.Images[35];
            narrowToolStripMenuItem.Image = imageListAdv1.Images[34];
            moderateToolStripMenuItem.Image = imageListAdv1.Images[33];
            wideToolStripMenuItem.Image = imageListAdv1.Images[40];
            legalToolStripMenuItem.Image = imageListAdv1.Images[31];
            letterToolStripMenuItem.Image = imageListAdv1.Images[32];
            tabloidToolStripMenuItem.Image = imageListAdv1.Images[39];
            executiveToolStripMenuItem.Image = imageListAdv1.Images[32];
            a3ToolStripMenuItem.Image = imageListAdv1.Images[39];
            a4ToolStripMenuItem.Image = imageListAdv1.Images[31];
        }

        #endregion

        #region Implementation
        /// <summary>
        /// Updates the Info backstage tab items.
        /// </summary>
        /// <param name="FileName"></param>
        private void InfoTabLabelUpdate(string FileName)
        {
            if (!string.IsNullOrEmpty(FileName))
            {
                FileInfo fileInformation = new FileInfo(FileName);
                lengthvaluelabel.Text = this.richTextBox1.TextLength.ToString() + " characters";
                documentLabel.Text = fileInformation.Name;
                sizevaluelabel.Text = (fileInformation.Length / 1000).ToString() + " KB";
                createdTimeValuelabel.Text = fileInformation.CreationTime.ToString();
                lastAccessValueLabel.Text = fileInformation.LastAccessTime.ToString();
            }
        }

        /// <summary>
        /// Resets the Info backstage tab details.
        /// </summary>
        void ResetLabels()
        {
            lengthvaluelabel.Text = this.richTextBox1.TextLength.ToString() + " characters";
            documentLabel.Text = "Info";
            sizevaluelabel.Text = "0 KB";
            createdTimeValuelabel.Text = DateTime.Now.ToString();
            lastAccessValueLabel.Text = "";
        }

        /// <summary>
        /// Updates the casing of the string.
        /// </summary>
        private string UppercaseFirst(string[] s)
        {
            string[] result = new string[] { };
            string strt = string.Empty;
            foreach (string str in s)
            {
                strt += char.ToUpper(str[0]) + str.Substring(1);
            }
            return strt;
        }

        /// <summary>
        /// Capitalizes the word of the string.
        /// </summary>
        private string[] CaptializeWord(string[] values)
        {

            string[] rtfText = new string[] { };
            TextInfo ti = CultureInfo.CurrentCulture.TextInfo;
            for (int i = 0; i < values.Count(); i++)
            {
                string text = values[i];
                text = ti.ToTitleCase(text);
                rtfText[i] += text;
            }
            return rtfText;
        }

        /// <summary>
        /// Formats the selected string.
        /// </summary>
        public void FormatSelectedString()
        {
            FontStyle style = FontStyle.Regular;
            if (boldToolStripButton.Checked)
            {
                style |= FontStyle.Bold;
            }
            if (strikeThroughButton.Checked)
            {
                style |= FontStyle.Strikeout;
            }
            if (underlineButton.Checked)
            {
                style |= FontStyle.Underline;
            }
            if (italicToolStripButton.Checked)
            {
                style |= FontStyle.Italic;
            }
            this.richTextBox1.SelectionFont = new Font(this.richTextBox1.Font.FontFamily, this.richTextBox1.Font.Size, style);
        }

        /// <summary>
        /// Sets the size for the landscape mode.
        /// </summary>
        /// <param name="width"></param>
        void SetLandscapeSize(float width)
        {
            this.rtbpanel.Width = (int)((this.Width) / width);
            this.rtbpanel.Location = new Point((this.Width - this.rtbpanel.Width) / 2, this.rtbpanel.Location.Y);
        }

        /// <summary>
        /// Add NumericDropDown control in the ToolStripEx.
        /// </summary>
        void AddNumericUpDownToPanelItem()
        {
            leftNumeric.Size = new System.Drawing.Size(90, 20);
            leftNumeric.Value = 0;
            leftNumeric.VisualStyle = Syncfusion.Windows.Forms.VisualStyle.Metro;
            leftNumeric.Minimum = 0;
            leftNumeric.Maximum = 500;
            leftNumeric.Increment = 1;
            leftNumeric.ValueChanged += LeftNumeric_ValueChanged;
            leftNumeric.VisualStyle = Syncfusion.Windows.Forms.VisualStyle.Office2016Colorful;
            ToolStripControlHost host1 = new ToolStripControlHost(leftNumeric);
            this.leftPanelItem.Items.Add(host1);
            rightNumeric.Size = new System.Drawing.Size(90, 20);
            rightNumeric.Value = 0;
            rightNumeric.Minimum = 0;
            rightNumeric.Maximum = 500;
            rightNumeric.Increment = 1;
            rightNumeric.VisualStyle = Syncfusion.Windows.Forms.VisualStyle.Metro;
            rightNumeric.ValueChanged += RightNumeric_ValueChanged;
            rightNumeric.VisualStyle = Syncfusion.Windows.Forms.VisualStyle.Office2016Colorful;
            ToolStripControlHost host2 = new ToolStripControlHost(rightNumeric);
            this.rightPanelItem.Items.Add(host2);
        }
        #endregion

        #region Events

        /// <summary>
        /// Occurs when form is resized.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Resize(object sender, EventArgs e)
        {
            int X = (this.Width / 2) - (this.richTextBox1.Width / 2);
            this.richTextBox1.Location = new Point(X, this.richTextBox1.Location.Y);
        }

        /// <summary>
        /// Occurs when the GalleryItem is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void toolStripGallery1_GalleryItemClicked(object sender, ToolStripGalleryItemEventArgs args)
        {
            if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 0)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Times New Roman", 11F);
                richTextBox1.SelectionColor = Color.Black;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 1)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 20F);
                richTextBox1.SelectionColor = Color.DarkBlue;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 2)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 18F);
                richTextBox1.SelectionColor = Color.DarkBlue;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 3)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 16F);
                richTextBox1.SelectionColor = Color.DarkBlue;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 4)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 14F);
                richTextBox1.SelectionColor = Color.DarkBlue;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 5)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 22F, FontStyle.Bold);
                richTextBox1.SelectionColor = Color.Black;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 6)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 15F, FontStyle.Italic);
                richTextBox1.SelectionColor = Color.Black;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 7)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 14F, FontStyle.Bold);
                richTextBox1.SelectionColor = Color.Black;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 8)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 14F, FontStyle.Underline);
                richTextBox1.SelectionColor = Color.Black;
            }
            else if (toolStripGallery1.Items.IndexOf(toolStripGallery1.SelectedItem) == 9)
            {
                richTextBox1.SelectionFont = new System.Drawing.Font("Segoe UI", 14F, FontStyle.Italic);
                richTextBox1.SelectionColor = Color.Black;
            }
        }

        /// <summary>
        /// Event that occurs once the size ComboBox is validated.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">event argument</param>
        private void SizeComboBox_Validated(object sender, EventArgs e)
        {
            if (sizeComboBox.SelectedIndex == -1)
            {
                sizeComboBox.SelectedIndex = storedsizeindex;
            }
        }

        /// <summary>
        /// Event that occurs once the font ComboBox is validated.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">event argument</param>
        private void FontComboBox_Validated(object sender, EventArgs e)
        {
            if (fontComboBox.SelectedIndex == -1)
            {
                fontComboBox.SelectedIndex = storedfontindex;
            }
        }

        /// <summary>
        /// Evevnt that occurs before a form is displayed for the first time.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            savedsize = this.rtbpanel.Size;
            savedLocation = this.rtbpanel.Location;
            this.highlightSplitButton.DropDown = new CustomDropDown(colorpicker1);
            this.fontColorSplitButton.DropDown = new CustomDropDown(colorpicker2);
            AddNumericUpDownToPanelItem();
            this.richTextBox1.SelectionChanged += RichTextBox1_SelectionChanged;
        }

        /// <summary>
        /// Closes the backstage. 
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void closebackStageButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.ResetText();
            this.wordribbon.BackStageView.HideBackStage();
            ResetLabels();
        }

        /// <summary>
        /// Pastes the copied text in the RichTextBox.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void pasteSplitButton_ButtonClick(object sender, EventArgs e)
        {
            this.richTextBox1.Paste();
        }

        /// <summary>
        /// Occurs when cut button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void cutButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.richTextBox1.SelectedText))
            {
                Clipboard.SetText(this.richTextBox1.SelectedText);
                this.richTextBox1.Cut();
            }
        }

        /// <summary>
        /// Occurs when copy button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void copyButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.richTextBox1.SelectedText))
            {
                Clipboard.SetText(this.richTextBox1.SelectedText);
                this.richTextBox1.Copy();
            }
        }

        /// <summary>
        /// Occurs when RichTextBox selection is changed.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void RichTextBox1_SelectionChanged(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle style = this.richTextBox1.SelectionFont.Style;
                if (style == FontStyle.Bold)
                    this.boldToolStripButton.Checked = true;
                else if (style == FontStyle.Italic)
                    this.italicToolStripButton.Checked = true;
                else if (style == FontStyle.Strikeout)
                    this.strikeThroughButton.Checked = true;
                else if (style == FontStyle.Underline)
                    this.underlineButton.Checked = true;
                else if (style == FontStyle.Regular)
                {
                    this.boldToolStripButton.Checked = false;
                    this.italicToolStripButton.Checked = false;
                    this.strikeThroughButton.Checked = false;
                    this.underlineButton.Checked = false;
                }
            }
            else
            {
                this.boldToolStripButton.Checked = false;
                this.italicToolStripButton.Checked = false;
                this.strikeThroughButton.Checked = false;
                this.underlineButton.Checked = false;
            }
        }

        /// <summary>
        /// Occurs when selected font is changed.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void fontComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string font = this.fontComboBox.Text;
            if (this.sizeComboBox.Items.Contains(this.sizeComboBox.Text))
            {
                float size = Convert.ToSingle(this.sizeComboBox.Text);
                richTextBox1.SelectionFont = new Font(font, size);
            }
            if (fontComboBox.SelectedIndex != -1)
            {
                storedfontindex = fontComboBox.SelectedIndex;
            }
            if (fontComboBox.SelectedIndex == -1)
            {
                fontComboBox.SelectedIndex = storedfontindex;
            }
            if (sizeComboBox.SelectedIndex != -1)
            {
                storedsizeindex = sizeComboBox.SelectedIndex;
            }
            if (sizeComboBox.SelectedIndex == -1)
            {
                sizeComboBox.SelectedIndex = storedsizeindex;
            }
        }

        /// <summary>
        /// Occurs when the increase font size button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void increaseFontSizeButton_Click(object sender, EventArgs e)
        {
            float size = this.richTextBox1.Font.Size + 1;
            richTextBox1.SelectionFont = new Font(richTextBox1.Font.FontFamily, size);
        }

        /// <summary>
        /// Occurs when the decrease font size button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void decreaseFontSizeButton_Click(object sender, EventArgs e)
        {
            float size = this.richTextBox1.Font.Size - 1;
            richTextBox1.SelectionFont = new Font(richTextBox1.Font.FontFamily, size);
        }

        /// <summary>
        /// Occurs when change font case button is clicked
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void changeCaseDropDownButton_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem == this.upperCaseToolStripMenuItem)
                richTextBox1.SelectedText = richTextBox1.SelectedText.ToUpper();
            else if (e.ClickedItem == this.lowerCaseToolStripMenuItem)
                richTextBox1.SelectedText = richTextBox1.SelectedText.ToLower();
            else if (e.ClickedItem == this.sentenceCaseToolStripMenuItem)
            {
                string[] rtftextarray = richTextBox1.SelectedText.Split('.');
                richTextBox1.SelectedText = UppercaseFirst(rtftextarray);
            }
            else if (e.ClickedItem == this.capitializeEachWordToolStripMenuItem)
            {
                TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
                richTextBox1.Text = textInfo.ToTitleCase(richTextBox1.Text);
            }
        }

        /// <summary>
        /// Occurs when bold button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void boldToolStripButton_Click(object sender, EventArgs e)
        {
            FormatSelectedString();
        }

        /// <summary>
        /// Occurs when super script button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void superScriptButton_Click(object sender, EventArgs e)
        {
            subScriptButton.Checked = false;
            if (superScriptButton.Checked)
                this.richTextBox1.SelectionCharOffset = 10;
            else
                this.richTextBox1.SelectionCharOffset = 0;
        }

        /// <summary>
        /// Occurs when subscript buutton is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void subScriptButton_Click(object sender, EventArgs e)
        {
            superScriptButton.Checked = false;
            if (subScriptButton.Checked)
                this.richTextBox1.SelectionCharOffset = -10;
            else
                this.richTextBox1.SelectionCharOffset = 0;
        }

        /// <summary>
        /// Occurs when Picture button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            OpenFileDialog OpenFileDialog1 = new OpenFileDialog();
            OpenFileDialog1.Filter = "All files |*.*";
            OpenFileDialog1.Multiselect = true;
            object orgdata = Clipboard.GetDataObject();

            if (OpenFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                foreach (string fname in OpenFileDialog1.FileNames)
                {
                    Image img = Image.FromFile(fname);
                    Clipboard.SetImage(img);
                    richTextBox1.Paste();

                }
            }
            Clipboard.SetDataObject(orgdata);
        }

        /// <summary>
        /// Occurs when bullet button is clicked which updates the RichTextBox.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void bulletSplitButton_ButtonClick(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionBullet = true;
        }

        /// <summary>
        /// Occurs when color is selected in the ColorPicker.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="args">args</param>
        private void Colorpicker2_Picked(object sender, ColorPickerUIAdv.ColorPickedEventArgs args)
        {
            this.richTextBox1.SelectionColor = args.Color;
        }

        /// <summary>
        /// Occurs when color is selected in the ColorPicker.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="args">args</param>
        private void Colorpicker1_Picked(object sender, ColorPickerUIAdv.ColorPickedEventArgs args)
        {
            this.richTextBox1.SelectionBackColor = args.Color;
        }

        /// <summary>
        /// Occurs when increase indent button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void incIndentButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionIndent = indentText++;
        }

        /// <summary>
        /// Occurs when decrease indent button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void decIndentButton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionIndent = indentText--;
        }

        /// <summary>
        /// Occurs when right alignment button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void RightButton_Click(object sender, System.EventArgs e)
        {
            this.richTextBox1.SelectionAlignment = HorizontalAlignment.Right;
        }

        /// <summary>
        /// Occurs when center alignment button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void CenterButton_Click(object sender, System.EventArgs e)
        {
            this.richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
        }

        /// <summary>
        /// Occurs when left alignment button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void LeftButton_Click(object sender, System.EventArgs e)
        {
            this.richTextBox1.SelectionAlignment = HorizontalAlignment.Left;
        }

        /// <summary>
        /// Occurs when a bullet item is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void bulletSplitButton_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem == noneMenuItem)
                this.richTextBox1.SelectionBullet = false;
            else
                this.richTextBox1.SelectionBullet = true;
        }

        /// <summary>
        /// Event that occurs when cover page dropdown button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void coverPageDropDownButton_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem == specDesignToolStripMenuItem)
                this.richTextBox1.LoadFile("..//..//Resources//Documents//Document1.rtf");
            if (e.ClickedItem == reportDeisgnToolStripMenuItem)
                this.richTextBox1.LoadFile("..//..//Resources//Documents//Document2.rtf");
            if (e.ClickedItem == resumeToolStripMenuItem)
                this.richTextBox1.LoadFile("..//..//Resources//Documents//Document3.rtf");
            if (e.ClickedItem == coverLetterToolStripMenuItem)
                this.richTextBox1.LoadFile("..//..//Resources//Documents//Document4.rtf");
        }

        /// <summary>
        /// Event that occurs when blank document button is clicked.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void blankDocumentbutton_Click(object sender, EventArgs e)
        {
            this.richTextBox1.ResetText();
            ResetLabels();
            this.wordribbon.BackStageView.HideBackStage();
        }

        /// <summary>
        /// Updates the size and location as per the orientation selected. 
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void orientationDropDownButton_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem != lastclickedItem)
            {
                if (e.ClickedItem == this.landscapeToolStripMenuItem)
                {
                    savedsize = this.rtbpanel.Size;
                    savedLocation = this.rtbpanel.Location;
                    SetLandscapeSize(1.75F);
                }
                else
                {
                    this.rtbpanel.Size = savedsize;
                    this.rtbpanel.Location = savedLocation;
                }
                lastclickedItem = e.ClickedItem;
            }
        }

        /// <summary>
        /// Updates the RichTextBox settings based on the margin item selected.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void marginDropDownButton_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem != lastclickedmarginItem)
            {
                if (e.ClickedItem == normalToolStripMenuItem)
                {
                    richTextBox1.SelectAll();
                    richTextBox1.SelectionIndent = 80;
                    richTextBox1.SelectionRightIndent = 80;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.DeselectAll();
                }
                else if (e.ClickedItem == moderateToolStripMenuItem)
                {
                    richTextBox1.SelectAll();
                    richTextBox1.SelectionIndent = 60;
                    richTextBox1.SelectionRightIndent = 60;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.DeselectAll();
                }
                else if (e.ClickedItem == wideToolStripMenuItem)
                {
                    richTextBox1.SelectAll();
                    richTextBox1.SelectionIndent = 190;
                    richTextBox1.SelectionRightIndent = 190;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.DeselectAll();
                }
                else if (e.ClickedItem == narrowToolStripMenuItem)
                {
                    richTextBox1.SelectAll();
                    richTextBox1.SelectionIndent = 30;
                    richTextBox1.SelectionRightIndent = 30;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.DeselectAll();
                }
                lastclickedmarginItem = e.ClickedItem;
            }
        }

        /// <summary>
        /// Updates the size based on the item selected.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void sizeDropDownButton_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem != lastclickedsizeItem)
            {
                if (e.ClickedItem == letterToolStripMenuItem)
                {
                    SetLandscapeSize(2);
                }
                else if (e.ClickedItem == legalToolStripMenuItem)
                {
                    SetLandscapeSize(2);
                }
                if (e.ClickedItem == a3ToolStripMenuItem)
                {
                    SetLandscapeSize(1.3F);
                }
                if (e.ClickedItem == a4ToolStripMenuItem)
                {
                    SetLandscapeSize(2.3F);
                }
                if (e.ClickedItem == tabloidToolStripMenuItem)
                {
                    SetLandscapeSize(1.75F);
                }
                if (e.ClickedItem == executiveToolStripMenuItem)
                {
                    SetLandscapeSize(1.3F);
                }
            }
            lastclickedsizeItem = e.ClickedItem;
        }

        /// <summary>
        /// Occurs when NumericUpDownExt value is changed.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void RightNumeric_ValueChanged(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionRightIndent = (int)this.rightNumeric.Value;
        }

        /// <summary>
        /// Occurs when NumericUpDownExt value is changed.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">args</param>
        private void LeftNumeric_ValueChanged(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionIndent = (int)this.leftNumeric.Value;
        }
        #endregion
    }

    #region Custom class to display the ColorPicker
    /// <summary>
    ///  Custom dropdown class for dropdown button to display the ColorPicker.
    /// </summary>
    public class CustomDropDown : ToolStripDropDown
    {
        public CustomDropDown(ColorPickerUIAdv colorpicker)
        {
            this.Height = colorpicker.Height;
            this.Items.Add(new ToolStripControlHost(colorpicker));
        }
    }
    #endregion
}
